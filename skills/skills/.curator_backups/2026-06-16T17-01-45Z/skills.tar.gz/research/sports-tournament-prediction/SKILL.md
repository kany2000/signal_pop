---
name: sports-tournament-prediction
description: Multi-factor tournament winner prediction using odds analysis, team/player evaluation, historical patterns, and weighted scoring models.
tags: [sports, betting, odds-analysis, prediction, tournament, football, soccer, world-cup]
related_skills:
  - public-api-data-retrieval
  - automation-architecture
  - signal-pop-news-pipeline
---

# Sports Tournament Prediction Methodology

## Overview

Predicting tournament winners using a systematic multi-factor analysis framework. Combines betting odds cross-referencing, team/player evaluation, historical pattern analysis, and weighted scoring for final probability estimates.

**Triggers:**
- User asks "who will win" a tournament
- Need to analyze team strengths ahead of a competition
- Multi-factor evaluation with confidence intervals
- Cross-bookmaker odds anomaly detection

---

## The Model

### Multi-Factor Weighted Scoring

```
夺冠概率 = 
    阵容实力(25%) × 阵容评分 +
    球员状态(20%) × 球员评分 +
    教练能力(15%) × 教练评分 +
    赛程难度(15%) × 路线评分 +
    历史数据(10%) × 历史评分 +
    博彩共识(10%) × 赔率评分 +
    外部因素(5%) × 外部评分
```

Each sub-score: 0-100 scale. Multiply by weight → weighted contribution.
Sum across factors → raw score. Normalize to probability distribution (all teams sum to ~100%).

### Confidence Intervals

Assign each probability a confidence band (±X%) based on:
- Data freshness (weeks old vs days old)
- Source diversity (single source vs multi-source consensus)
- Historical accuracy of similar predictions
- Known unknowns (injuries, draws, upsets)

---

## Factor Detail

### 1. 阵容实力 (Squad Strength) — 25%
- Depth rating: S (10), A (8-9), B (6-7), C (4-5)
- Injury tolerance: how many key players can be lost
- Positional strength: weakest position drags down score
- Age profile: peak age ~25-28 for outfield, ~28-32 for GK
- Source: Transfermarkt, FIFA, squad lists

### 2. 球员状态 (Player Form) — 20%
- Key players: identify 1-3 indispensable players
- Recent form: club performance in season leading up to tournament
- Injury risk: historical fitness, muscle issues, recent absences
- Fatigue: total matches played in last season (>55 = high risk)
- Source: club stats, injury reports, news aggregators

### 3. 教练能力 (Coaching) — 15%
- Tournament experience: previous WC/continental tournament results
- Tactical adaptability: plan A, B, C
- Man management: handling egos, squad rotation
- Set piece strategy: ~30% goals from set pieces
- Source: press conferences, past tournament results, tactical analysis

### 4. 赛程难度 (Tournament Path) — 15%
- Group stage difficulty: pot seeding analysis
- Knockout bracket: which half of the draw — death half vs light half
- Travel distance between venues (multi-host tournament factor)
- Rest days between matches
- Source: official draw results, venue map, schedule

### 5. 历史数据 (Historical Patterns) — 10%
- Past tournament performance (last 4 editions weighted)
- Head-to-head vs potential bracket opponents
- "Curse" patterns: defending champion curse, host nation advantage
- Penalty shootout record
- Source: FIFA data, Wikipedia, Opta

### 6. 博彩共识 (Betting Consensus) — 10%
- Cross-bookmaker comparison (FanDuel, Bet365, Pinnacle, William Hill)
- Look for **divergence**: large gaps between bookmakers = value signal
- Odds movement trend: shortening (confidence↑) vs drifting (confidence↓)
- Implied probability: 1 / decimal_odds * 100
- Source: The Odds API, Oddschecker, individual bookmaker sites

### 7. 外部因素 (External Factors) — 5%
- Host nation advantage: quantifiable as +10-15%
- Geopolitical tensions: travel restrictions, player visas
- Weather: extreme heat/cold favors certain playing styles
- Political protests, social unrest near venues
- Source: news, local knowledge, climate data

---

## Odds Anomaly Detection

One of the highest-value signals. Compare 5+ bookmakers for the same market.

**Method:**
1. Collect decimal odds from each bookmaker for ALL teams
2. Calculate implied probability: 1/odds × 100
3. Find teams with max(implied) - min(implied) ≥ 5pp divergence
4. These are **anomaly signals** — market hasn't converged
5. Investigate why: local betting patterns, injury news, information asymmetry

**Example finding (World Cup 2026):**
| Bookmaker | France | England | Argentina |
|-----------|--------|---------|-----------|
| FanDuel   | +460   | +700    | +950      |
| Bet365    | +400   | +700    | +500      |
| Transfermarkt ELO | 8.0-9.0 | — | — |

France showed 50% divergence between FanDuel (+460 → 17.9%) and Transfermarkt (8.0-9.0 → 11.1-12.5%), suggesting either a market inefficiency or a model disagreement.

---

## Operations: Daily Intelligence Collection

For tournaments that run over weeks, set up an automated **daily collection pipeline** to gather fresh signals while the tournament approaches.

### Pattern: Cron-Based Collection

```
Jun 3 ──→ daily_collection/report_0603.txt
Jun 4 ──→ daily_collection/report_0604.txt
Jun 5 ──→ daily_collection/report_0605.txt
               ↓
Jun 8 ──→ Read all reports → final analysis
```

**Implementation steps:**

1. **Build a collection script** (Python + RSS/API) that:
   - Fetches from 3+ news RSS feeds (BBC Sport, Guardian, Sky Sports work reliably)
   - Filters articles by tournament keywords (team names, "injury", "squad", "odds")
   - Classifies articles by type: INJURY / SQUAD / COACHING / ODDS / MATCH / GENERAL
   - Extracts team mentions and builds a "top N teams today" signal
   - Saves structured daily report + raw JSON to disk

2. **Schedule daily collection** via cron:
   - Use `deliver: "local"` for daily jobs — saves files without spamming the chat
   - Use `repeat=N` to limit runs (e.g. repeat=5 for 5 days of collection)
   - Set schedule to run at a fixed time each day (e.g. noon local time)

3. **Schedule final compilation** via cron:
   - Use `deliver: "origin"` for the final output day
   - Set the one-shot ISO timestamp as schedule: `2026-06-08T09:00:00`
   - The final job reads all daily reports + prior analysis, then outputs the updated prediction

### RSS Feeds That Work

| Source | URL | Reliability |
|--------|-----|-------------|
| BBC Sport | `https://feeds.bbci.co.uk/sport/football/rss.xml` | ★★★★★ — reliable, 80+ items |
| The Guardian | `https://www.theguardian.com/football/rss` | ★★★★★ — reliable, 60+ items |
| Sky Sports | `https://www.skysports.com/rss/12040` | ★★★★☆ — reliable, 20+ items |

### When Paid APIs Fail (& Free Alternatives)

The Odds API free tier (500 req/mo, ~16/day) is easily exhausted during active tournaments. When it runs out (error: `OUT_OF_USAGE_CREDITS`), use these free alternatives.

**Bottom line (June 2026)**: Register for both The Odds API free tier AND Oddsble free tier upfront. The Odds API is the most reliable single source for outright winner odds (500 req/mo free). When exhausted, Oddsble is the best free replacement with identical quota. Combined, they provide ~1000 free requests/month — enough for a full tournament cycle with daily polling.

**⚠️ SportAPI7 verification**: Despite claims from other sources, SportAPI7 has **NO outright winner odds** — only match odds (1X2). Tested with live API calls. See `references/free-odds-apis.md` for the full verification report and lesson about verifying API claims.

#### 🥇 Oddsble API (Best Free Option for Outright Winner Odds — June 2026)

- **Free tier**: 500 requests/month — same as The Odds API starter tier
- **Outright winner odds**: ✅ — dedicated endpoint for tournament winner markets (claims outrights)
- **Dashboard**: `https://dashboard.oddsble.com/` → sign up for free API key
- **Base URL**: `https://api.oddsble.io/v1/` (exact endpoints TBC — checkout their doc after signup)
- **Why it matters**: The only free alternative that matches The Odds API quota (500 req/mo) AND claims outright winner odds. Register BOTH The Odds API and Oddsble for ~1000 combined free requests/month.
- **Caveat**: Newer service; WC2026 outright endpoint not verified with live call (requires signup). See `references/free-odds-apis.md` for full details and integration sketch.

#### 🥈 Free API Live Football Data via RapidAPI (Free Match-Level Odds — June 2026)
- **Free tier**: 100 requests/month (hard limit), 1000 req/h rate limit
- **Odds endpoint**: `[GET] /football-event-odds?eventid=X&countrycode=XX` — match-level 1X2 odds from Bet365 (confirmed working)
- **⚠️ NO outright winner market** — the odds endpoint only returns match-level 1X2. Cannot replace The Odds API for pre-tournament 夺冠赔率 predictions. Use only for in-tournament match odds or qualification-stage analysis.
- Covers World Cup (league ID 77) + 100+ leagues; WC Qualifier UEFA (league 10195) has 204 matches with odds
- **⚠️ API endpoint paths differ from RapidAPI UI labels** — always extract real paths from cURL snippets. See `references/free-odds-apis.md` for verified endpoint list and proven 404s.
- **Requires**: Free RapidAPI account → Subscribe to Basic plan at `https://rapidapi.com/Creativesdev/api/free-api-live-football-data/pricing`
- API key passed as `x-rapidapi-key` header
- Host: `free-api-live-football-data.p.rapidapi.com`
- **Best path when The Odds API quota is exhausted** for match-level odds; for outright winner odds, Fallback Strategy below applies.
- **⚠️ API-Football (previously recommended) is no longer reliably accessible** on RapidAPI — its page returns "API not found". See `references/free-odds-apis.md` for full details.

#### 🥈 Web Scraping (DIY, unreliable)
Targets that DO work with basic requests+BeautifulSoup:
- **BetExplorer** (`betexplorer.com`) — ✅ 200 OK, has match odds, ❌ NO outright winner odds for World Cup
- **TheSportsDB** (`thesportsdb.com`) — ✅ free API key "3", ❌ NO odds data at all (scores/fixtures only)
- **Football-Data.org** (`football-data.org`) — ✅ has World Cup league (ID=2000), ✅ free tier 10 req/min, ❌ odds = paid add-on (€15/mo)

Targets BLOCKED or unusable:
- **OddsChecker** (`oddschecker.com`) — ❌ Cloudflare 403
- **Oddspedia** (`oddspedia.com`) — ❌ Cloudflare 403
- **OddsPortal** (`oddsportal.com`) — ❌ Cloudflare 403
- **FlashScore** (`flashscore.com`) — ✅ 200 OK but odds loaded via GraphQL dynamically; needs headless browser (playwright/selenium) to render DOM
- **ESPN Public API** (`site.api.espn.com`) — ❌ All soccer odds endpoints return 404. Previously worked, now defunct.

#### Fallback Strategy
1. Try The Odds API first (most reliable, has outright winner odds, 500 req/mo)
2. On `OUT_OF_USAGE_CREDITS` → try **Oddsble API** (500 req/mo free, has outright winner odds — best direct replacement). Register at dashboard.oddsble.com
3. If Oddsble fails → try no-API scraping first (BetExplorer match odds, FlashScore via headless browser)
4. If no-API fails → switch to **Free API Live Football Data** via RapidAPI (100 req/mo free, match-level 1X2 only — no outright winner)
5. If outright winner odds are still needed → try **SportAPI** via RapidAPI (50 req/mo free) or install Playwright + render FlashScore DOM
6. **Cache fallback**: load `odds_latest.json` from disk. Label output `"cached from YYYY-MM-DD"`. Pipeline must NOT crash — produce output regardless with freshness annotation.
7. Ultimate last resort: pure RSS-derived sentiment + comprehensive analysis baseline, no odds factor.

**User preference note**: This user consistently prefers trying no-API/free solutions before registering for any service. Default to the no-API-first path when the budget constraint is mentioned ("优先不用API" / "免费为主"). Only escalate to API registration after confirming no-API alternatives don't meet the requirement.

**Do NOT attempt no-registration ESPN API** — all soccer/odds endpoints now return 404.

**⚠️ API-Football RapidAPI URL Issue (June 2026)**: The previously documented URL `https://rapidapi.com/api-sports/api/api-football/` now redirects to "API not found". This API may have been unpublished or restricted. **Do not recommend it as a primary option** — use **Free API Live Football Data** (Creativesdev) instead as the free RapidAPI alternative. See `references/free-odds-apis.md` for details.

---

## Principles

### Verify External Claims Before Reporting

When another source (another bot, external tool, or user) claims a specific API has certain data capabilities, **verify it yourself before reporting to the user**. Do not pass through uncorroborated claims.

**This came from a real failure**: Another bot claimed "SportAPI7 on RapidAPI has outright winner odds (夺冠赔率)". Direct API testing proved:
- RapidAPI key ✅ works, 50 req/day, 40 remaining
- WC2026 season exists (id=58210) ✅
- Match schedule ✅
- **Outright winner market ❌ — does not exist. All odds endpoints return 404. Match odds (1X2) only.**

**Common pitfalls:**
- RapidAPI playground labels / descriptions overstate capabilities — "odds" in the API title ≠ outright winner endpoint
- Other agents confidently repeat outdated or assumed capabilities
- Free API docs are aspirational, not factual; only a real API call proves existence

**Verification workflow:**
1. Make a real API call (curl/Python) to the claimed endpoint
2. Parse the response — does the field you need actually exist?
3. Test edge cases: different params, market types, sport keys
4. Report ONLY verified capabilities. If claim was wrong, say so clearly with evidence.

### Data-Driven Argumentation

When making predictions, **argue from data, not deference**. If the user proposes a hypothesis (e.g. "Team X can't win"), do NOT agree reflexively. Instead:

1. Check the data — what do the models, odds, and history say?
2. If the data supports the user's view, show the evidence
3. If the data contradicts the user's view, present the data honestly
4. Acknowledge uncertainty — confidence intervals, not false certitude

**Rule of thumb**: A prediction session where every answer aligns with the user's intuition is a session where you stopped thinking analytically. Tournament prediction is a data science exercise, not a diplomacy exercise.

### Graceful Degradation (Pipeline Must Not Crash)

When any external data source fails (API quota exhausted, HTTP timeout, 403/429), the pipeline MUST produce output regardless. **A partially-stale output is more useful than no output.**

**Implementation pattern:**
- Wrap each data source fetch in try/except
- On failure, load the most recent local cache (`odds_latest.json`, `daily_report_*.json`)
- Annotate output with data freshness: `"cached from YYYY-MM-DD"`
- The annotation lets the user assess reliability — no need to hide staleness
- Example: `collect_odds_api()` → returns latest data OR `load_cached_odds()` + sets `source_label="cached"`
- Downstream consumers (final_predict, analysis) read `source_label` from the data dict

**Design constraint**: The final prediction script must accept odds data with or without a "source" / "cached_at" field. Display it when present, omit when absent — never crash on missing keys.

### Signal vs Noise

Not every news article is a signal. Apply tiered relevance:
- **Tier 1 (Strong signal)**: Confirmed ACL/hamstring injury to a star player, surprise squad omission, coaching change, major odds movement (>20% shift)
- **Tier 2 (Weak signal)**: Player out-of-form, minor knocks, media speculation, friendly match results
- **Tier 3 (Noise)**: Press conference platitudes, fan theories, clickbait transfer rumors

Daily reports should flag Tier 1 items prominently and track Tier 2 items for accumulation.

---

## Scenario Simulation

Generate 3-4 distinct scenarios covering the range of plausible outcomes:

| Scenario | Description | Probability | Key Assumption |
|----------|-------------|-------------|----------------|
| A (Favorite) | Top seed wins | ~22% | No major upsets |
| B (Repeat) | Defending champion retains | ~17% | Core players peak form |
| C (Dark Horse) | New champion breaks through | ~11% | Coach effect + luck |
| D (Shock) | Unseeded winner | ~5% | Multiple favorites eliminated early |

Each scenario should include:
- Realistic elimination path (group → round of 16 → QF → SF → final)
- Key matchups that would need to happen
- One "moment" that defines the run (penalty save, long-range goal, etc.)

---

## Pipeline Pattern: No-Odds Fallback Collection

When the primary odds API quota is exhausted and no reliable free alternative for outright winner odds exists, use this **bootstrap pattern**:

### Flow

1. **Build comprehensive analysis** (one-time, ~1 week before deadline) using whatever odds data is available — even stale data is a baseline
2. **Daily RSS collection** → news signals (injuries, squad, coaching changes)
3. **Daily match-odds collection** from Free API Live Football Data (match-level 1X2 only — no outright winner, but shows market direction)
4. **Final compilation**: Read all daily reports + comprehensive analysis → generate prediction

### Implementation Sketch

```
scripts/
├── collect_daily.py      # RSS feeds → daily report + raw JSON
├── scrape_odds.py         # Free API Live Football Data → match odds
└── final_predict.py       # Read everything → prediction output
```

Two cron jobs:
1. `worldcup-daily-collect` — schedule `0 12 * * *`, repeat=N, deliver=local
   - Runs both `collect_daily.py` and `scrape_odds.py`
   - Saves to `daily_collection/` and `odds_data/`
2. `worldcup-final-analysis-june8` — one-shot ISO timestamp, deliver=origin
   - Runs `final_predict.py` which reads all saved data

### Bootstrap Prediction Pattern

When predicting a tournament that hasn't started yet (no match data), use this collection flow:

```
Phase 1 (1 week before)        Phase 2 (daily)                Phase 3 (deadline)
─────────────────────────────────────────────────────────────────────────────────
Write comprehensive analysis    Collect RSS news               Read all daily reports
(8-factor, ~20 pages)     →    + scrape match odds        →   + comprehensive analysis
Include best available odds     (qualifier matches,            + odds data
Baseline probabilities          team form signals)             → generate final prediction
```

**Key insight:** Stale odds (<2 weeks) are still directionally valid for a 10%-weighted factor. A comprehensive analysis from May remains useful in June — the odds market doesn't shift radically for tournament outright winners in 1-2 weeks unless a star player gets injured or a major coaching change happens.

### The Odds API Registration

**Updated URL (June 2026):** Register at `https://dash.the-odds-api.com/` — click "Create Account" tab. The old URL `the-odds-api.com/account/register` redirects to the dashboard login.

Free Starter tier: 500 credits/month. Sport key for outright winner: `soccer_fifa_world_cup_winner`. Supports **`outrights`** market type (NOT `h2h`) — passing `markets=h2h` for outright winner sports returns `INVALID_MARKET_COMBO` error. Always omit the `markets` parameter for outright winner endpoints and let the API return the default `outrights` market.

When the free tier is exhausted (`OUT_OF_USAGE_CREDITS` error around 16 req/day), create a new account with a different email for another 500 credits — valid for one-off tournament predictions.

### Pitfall: Intermittent "INVALID_KEY" responses

The Odds API free tier exhibits **intermittent key validation failures**. A fresh key may succeed on the first call (`GET /v4/sports/` → 48 sports returned ✅) then return `{"message":"API key is not valid"}` on subsequent calls. This is NOT key expiry — the same key works again after a 3-8 second pause. Root cause unknown (likely CloudFront caching + free tier throttling).

**Mitigation: Retry loop mandatory**

```python
def odds_api_fetch(url, retries=6):
    for i in range(retries):
        try:
            req = urllib.request.Request(url)
            with urllib.request.urlopen(req, timeout=15) as resp:
                data = json.loads(resp.read())
                if isinstance(data, list) or (isinstance(data, dict) and "message" not in data):
                    return data
                if isinstance(data, dict):
                    msg = data.get("message", "").lower()
                    if "invalid" not in msg:
                        return data
        except Exception:
            pass
        time.sleep(3 + 2 * i)  # increasing backoff
    return None
```

Always use retries when calling The Odds API, even on fresh keys. The first call (list sports) may work but the second (get odds) may fail — the retry loop saves this.

### Multi-Region Consensus Pattern

Single bookmaker odds are unreliable (regional bias, varying margins). Collect from 4 regions and compute consensus:

```python
team_odds = {}
for region in ["eu", "uk", "us", "au"]:
    url = f"{BASE}/soccer_fifa_world_cup_winner/odds/?apiKey={KEY}&regions={region}"
    data = fetch(url)
    if data and isinstance(data, list):
        for event in data:
            for bm in event.get("bookmakers", []):
                for m in bm.get("markets", []):
                    for o in m.get("outcomes", []):
                        team_odds.setdefault(o["name"], []).append(float(o["price"]))

consensus = {}
for team, ol in team_odds.items():
    avg = sum(ol) / len(ol)
    best = min(ol)
    consensus[team] = {"avg_odds": round(avg, 2), "best_odds": best, "implied_prob": round(100/avg, 1)}
```

This gives 4-region consensus across ~7 bookmakers. Compare US vs EU vs UK vs AU regions for divergence signals.

### Multi-Source Weighted Prediction Formula

When rolling up analysis + odds + news into a final prediction, use this weighted formula (validated June 2026):

```
score = baseline_prob × 0.4  +  market_odds_implied_prob × 0.3  +  news_mention_count × 0.3
```

Rationale:
- **40% baseline**: Comprehensive multi-factor analysis has the widest coverage (squad, coach, history, etc.) — should dominate
- **30% market odds**: Bookmaker consensus is directionally accurate but noisy on a 2-week horizon
- **30% news signal**: High-frequency signal that catches late-breaking injuries/squad news the baseline missed

For teams with no match-level data (pre-tournament), this formula stabilizes predictions across 2 weeks of daily collection.

### API Key Config Pattern

Store API keys in a `.odds_config.json` file adjacent to the collection scripts, with restricted permissions:

```json
{"rapidapi_key": "...", "odds_api_key": "..."}
```

```python
# Load at runtime
cfg_path = Path.home() / "worldcup-analysis" / ".odds_config.json"
if cfg_path.exists():
    cfg = json.loads(cfg_path.read_text())
    ODDS_API_KEY = cfg.get("odds_api_key", "")
    
# Save via CLI flag
def save_config(key, value):
    cfg = load_config()
    cfg[key] = value
    cfg_path.write_text(json.dumps(cfg, indent=2))
    os.chmod(str(cfg_path), 0o600)  # owner-only read
```

Do NOT hardcode keys in scripts or share via chat — use `--save-odds-api KEY` workflow.

### Critical constraint

`scrape_odds.py` now uses **Free API Live Football Data** (host: `free-api-live-football-data.p.rapidapi.com`) instead of the defunct API-Football. The new endpoints differ completely from the old ones — see `references/free-odds-apis.md` for the verified path list.

### Pitfall: Emoji-stripped team names

When parsing a probability table like:
```
| 🥇 | 🇫🇷 **法国** | **22%** | 高 |
```

The regex `r'[^\w\s\-äöüéèêëàâîôùûç]'` strips non-text chars (medal emojis, flag emojis) while preserving Chinese/European characters in team names. The simpler approach of `re.sub(r'[🇦-🇿🟦⬜🟩🟥🟨🌟⭐*]', ...)` fails because:
- Medal emojis (🥇🥈🥉) aren't covered by the flag emoji range
- The flag emoji regex pattern is fragile and locale-dependent
- **Always use `[^\w\s\-...]` negation class** as the parse-and-reject strategy instead of listing emoji characters

## Data Sources & Reliability

| Source Type | Reliability | Notes |
|-------------|-------------|-------|
| FIFA Official Data | ★★★★★ | Historical results, fixtures, rankings |
| Transfermarkt | ★★★★★ | Squad values, player profiles, market data |
| The Odds API | ★★★★☆ | Real-time odds, requires API key, 500 req/mo free then paid |
| ESPN Public API | ★☆☆☆☆ | Dead/404 as of June 2026. Previously free no-key odds, now all endpoints return 404. Do not use. |
| Free API Live Football Data (RapidAPI) | ★★★☆☆ | 100 req/mo free, match odds only (no outright winner), API quality mediocre, endpoints inconsistent |
| Oddschecker | ★★★★☆ | Aggregated odds, good for comparison, may block bots |
| BBC/Sky Sports | ★★★★☆ | News, analysis, injury updates |
| Opta/Stats Perform | ★★★★★ | Advanced metrics (xG, possession, passing) |
| Wikipedia | ★★★★☆ | Historical data, tournament summaries |

---

## Pitfalls

- **API keys may expire**: The Odds API needs periodic key renewal. Free tier = 500 req/mo (~16/day); easily exhausted during active tournaments. Fallback: **Free API Live Football Data** via RapidAPI (100 req/mo free, match odds only) or BetExplorer scraping for match odds.
- **⚠️ Free API Live Football Data has NO outright winner odds**: Only match-level 1X2. Cannot substitute for The Odds API for pre-tournament 夺冠赔率. For outright winner odds, need SportAPI, FlashScore (headless), or paid Odds API.
- **⚠️ API-Football RapidAPI page broken**: As of June 2026, `https://rapidapi.com/api-sports/api/api-football/` returns "API not found". Do not rely on it. Use Free API Live Football Data (Creativesdev) as the RapidAPI alternative instead.
- **Odds ≠ probability**: Betting odds include bookmaker margin (overround ~5-8%). Always normalize.
- **Squad lists change**: Last-minute injury withdrawals invalidate pre-tournament analysis. Set a "final squad" deadline for the definitive prediction.
- **Friendlies are unreliable**: Pre-tournament friendly matches are not representative — players are conserving energy.
- **48-team format**: Expanded tournaments increase group-stage upset probability but don't change champion profile much.
- **Recency bias**: Recent performances often overweighted. Balance with long-term data.
- **Cross-bookmaker scraping**: Many sites block bots. Use official APIs where available.

---

## Output Format

For the final prediction, present:

1. **Probability table**: Top 8+ teams with scores and confidence bands
2. **Key signals**: What moved the numbers (injuries, odds shifts, coach changes)
3. **Final pick**: One clear recommendation with rationale
4. **Risk factors**: What would change the prediction (top player injured, etc.)
5. **Dark horse**: One non-favorite to watch

---

## Related Files

- `references/world-cup-2026-prediction.md` — Full World Cup 2026 analysis example (May 2026 data, 8-factor scoring model)
- `references/world-cup-2026-collection-pipeline.md` — Operational record: RSS-based daily collection cron pipeline built for the June 2026 prediction run
- `references/free-odds-apis.md` — Free alternatives to The Odds API: Free API Live Football Data, SportAPI, web scraping targets, decision flow (updated June 2026 with real-world test results and API-Football URL caveat)
- `references/cache-fallback-implementation.md` — Concrete code pattern for graceful cache fallback when primary API quota exhausted
