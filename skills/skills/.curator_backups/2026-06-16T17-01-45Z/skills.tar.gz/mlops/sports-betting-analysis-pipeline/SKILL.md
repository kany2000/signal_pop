---
name: sports-betting-analysis-pipeline
description: Multi-source sports betting analysis pipeline — quota-aware API orchestration, daily data collection, historical baselines, real-time odds, news signals, and weighted prediction generation.
category: mlops
tags: [sports-betting, odds-api, data-pipeline, prediction, world-cup]
---

# Sports Betting Analysis Pipeline

## Overview
Reusable pattern for tournament-level betting analysis (World Cup, Euros, etc.) combining:
- **Multiple odds APIs** with quota tracking (The Odds API, RapidAPI providers)
- **Daily news collection** via RSS feeds (BBC, Guardian, Sky Sports)
- **Historical baseline** from comprehensive pre-tournament analysis
- **Real-time match odds** for specific fixtures
- **Weighted prediction model** (baseline + market + news signals)

## Architecture

```
┌─────────────┐     ┌─────────────┐     ┌─────────────┐
│  Odds APIs  │     │  RSS Feeds  │     │  Baseline   │
│  (quota-mgr)│     │  (daily)    │     │  (static)   │
└──────┬──────┘     └──────┬──────┘     └──────┬──────┘
       │                   │                   │
       └───────────────────┼───────────────────┘
                           ▼
              ┌─────────────────────────┐
              │   odds_latest.json      │
              │   daily_collection/     │
              │   FINAL_COMPREHENSIVE_  │
              │   ANALYSIS.md           │
              └───────────┬─────────────┘
                          ▼
              ┌─────────────────────────┐
              │  final_predict.py       │
              │  (weighted scoring)     │
              └───────────┬─────────────┘
                          ▼
              ┌─────────────────────────┐
              │  Champion / Runner-up   │
              │  Top 4 / Dark Horse     │
              │  Match-specific odds    │
              └─────────────────────────┘
```

## Key Scripts (in project `scripts/`)

| Script | Purpose | Schedule |
|--------|---------|----------|
| `scrape_all.py` | Fetch all odds sources → `odds_latest.json` | Manual / pre-match |
| `collect_daily.py` | RSS news → `daily_collection/report_YYYY-MM-DD.txt` | Cron daily 08:30 |
| `final_predict.py` | Combine all sources → prediction | Manual / pre-match |

## API Quota Management

**The Odds API** (primary for outright winner + match odds)
- Free tier: 500 requests/month
- Endpoint: `soccer_fifa_world_cup_winner` + `soccer_fifa_world_cup`
- Check quota via response headers or dashboard
- **Pitfall**: Returns `match_odds` as **list** (not dict) — iterate directly

**RapidAPI: free-api-live-football-data** (backup for qualifiers)
- Free tier: monthly quota, often exhausted early
- Returns 429 when quota exceeded
- Use only for qualifier match odds (not outright winner)

## Data Structures

### `odds_latest.json` (output of `scrape_all.py`)
```json
{
  "timestamp": "2026-06-10 10:12:25",
  "free_api": null,
  "odds_api": {
    "source": "The Odds API",
    "winner_odds": { "eu": [...], "uk": [...], ... },
    "match_odds": [                    // ← LIST, not dict
      {
        "home_team": "Mexico",
        "away_team": "South Africa",
        "commence_time": "2026-06-11T19:00:00Z",
        "bookmakers": [...]
      },
      ...
    ]
  }
}
```

### `daily_collection/report_YYYY-MM-DD.txt`
Structured RSS report with:
- Injury / Squad / Coaching / Odds / Match classifications
- Team mention frequency (signal strength)
- Key signal flags (⚠️ injury, 🔄 coaching change)

### `FINAL_COMPREHENSIVE_ANALYSIS.md`
Pre-tournament baseline with probability table:
```
| 排名 | 球队 | 概率 |
|------|------|------|
| 1    | 法国 | 22%  |
| 2    | 阿根廷 | 17% |
...
```

## Prediction Model (final_predict.py)

**Weighted scoring**:
```
combined = baseline * 0.4 + market_implied * 0.3 + news_signals * 0.3
```
- Baseline: from comprehensive analysis (static, pre-tournament)
- Market implied: from `odds_latest.json` consensus odds
- News signals: team mention count in daily reports (capped)

**Output**:
- 🥇 Champion, 🥈 Runner-up, 🥉 Top 4, 🌟 Dark Horse
- Risk flags (⚠️ injury signals)
- Detailed scoreboard with component breakdown

## Common Operations

### Refresh odds (pre-match)
```bash
cd ~/worldcup-analysis
python3 scripts/scrape_all.py
python3 scripts/final_predict.py
```

### Query specific match odds
```python
import json
with open('odds_data/odds_latest.json') as f:
    data = json.load(f)
for match in data['odds_api']['match_odds']:
    if 'mexico' in match['home_team'].lower() and 'south africa' in match['away_team'].lower():
        for bm in match['bookmakers']:
            for market in bm['markets']:
                if market['key'] == 'h2h':
                    for o in market['outcomes']:
                        print(f"{o['name']}: {o['price']}")
```

### Check API quota status
```bash
# The Odds API: check dashboard or response headers
# RapidAPI: run scrape_odds.py → 429 = quota exhausted
```

## Pitfalls & Gotchas

1. **`match_odds` is a list** — not a dict keyed by region. Iterate directly.
2. **RapidAPI free tier dies fast** — don't rely on it for daily updates. The Odds API is more reliable.
3. **Odds update frequency** — match odds can change multiple times/day. Refresh `scrape_all.py` on match day morning.
4. **Timezones** — `commence_time` is UTC. Convert for local display (e.g., +8 for Beijing).
5. **Missing match odds** — not all fixtures have odds early. Check `match_odds` length vs expected fixtures.
6. **News signal noise** — RSS picks up generic mentions. Filter keywords carefully (`WC_KEYWORDS` in `collect_daily.py`).

## Extending for Other Tournaments

Replace sport keys:
- World Cup: `soccer_fifa_world_cup_winner` + `soccer_fifa_world_cup`
- Euros: `soccer_uefa_euro_winner` + `soccer_uefa_euro`
- Champions League: `soccer_uefa_champs_league_winner` + `soccer_uefa_champs_league`

Update `TEAMS` list in `collect_daily.py` and `final_predict.py` for tournament participants.

## References
- `references/odds-api-structure.md` — The Odds API response format details
- `references/rapidapi-quotas.md` — RapidAPI provider limits and fallback logic
- `references/prediction-weights.md` — Weight tuning rationale and backtesting notes