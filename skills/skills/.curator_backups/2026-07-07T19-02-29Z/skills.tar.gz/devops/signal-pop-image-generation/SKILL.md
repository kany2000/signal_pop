---
name: signal-pop-image-generation
description: 信号弹新闻配图自动化。为 signal_pop daily/weekly 新闻稿生成新闻配图。
---

# 信号弹新闻配图自动化

为 Signal Pop (隔天信号弹) 新闻稿自动生成配图。

## 定时任务

- **Cron job ID:** `92ef826414c5`
- **Schedule:** `30 9 * * 0,2,4,5` (每周日/二/四/五 09:30)
- **触发时机:** 新闻稿 09:00 出稿后 30 分钟自动运行
- **触发脚本:** `gen_news_images.py`（自动匹配，适合无人值守 cron）

## 数据源

- **Daily:** `/home/kan/shared/signal_pop/archive/signal_pop_daily_YYYYMMDD.txt`
- **Weekly:** `/home/kan/shared/signal_pop/archive/signal_pop_weekly_YYYYMMDD.txt`

## 输出路径

- **Daily 配图:** `/home/kan/shared/signal_pop/archive/img_YYYYMMDD/` (01.jpg ~ NN.jpg)
- **Weekly 配图:** `/home/kan/shared/signal_pop/archive/img_weekly_YYYYMMDD/`

## 相关脚本

- 定制版：`/home/kan/shared/signal_pop/scripts/gen_custom_images.py`（手动编辑prompt列表）
- 旧版：`/home/kan/shared/signal_pop/scripts/gen_news_images.py`（keyword_map 匹配，不推荐）
- 视频合成：`/home/kan/signal_pop/scripts/build_daily_video.py`（将本技能产出的配图合成为视频）

## 与视频管线关系

本技能生成的 images（img_YYYYMMDD/01.jpg–10.jpg）是视频管线 `signal-pop-news-video-pipeline` Approach C 的直接输入。流程：
```
新闻稿 → 本技能产出配图（10张）→ tts_mimo 语音 → build_daily_video.py 合成MP4 → her2home/ → auto_publish 分发
```
/home/kan/shared/signal_pop/scripts/gen_news_images.py
```
- 正则匹配标题，自动适配任意条目数
- 同时处理 daily 和 weekly
- keyword_map 匹配 + fallback 模板（质量一般，fallback 时可能生成通用科技图）

### 定制版（高质量，手动编辑 prompt 列表）
```bash
/home/kan/shared/signal_pop/scripts/gen_custom_images.py
```
- 每条新闻独立定制英文 prompt
- 必须手动编辑 prompt 列表匹配当天新闻（约10条英文prompt占位）
- ⚠️ **Build script sets via env**: `read -p "Enter 10 prompts..."` — 需先编辑脚本中的 prompt 数组
- 该脚本需手动生成，自动版(cron)走 keyword_map 匹配

## 配图引擎

- **Pollinations AI** — `https://image.pollinations.ai/prompt/{encoded_prompt}?width=1024&height=576&seed={seed}&model=flux&nofeed=true`
- 必须带 `User-Agent: Mozilla/5.0` 头，否则 403
- `&nofeed=true` 防止返回 HTML 而非图片
- `model=flux` 使用 Flux 模型（比默认模型质量好）
- `seed` 参数确保不重复（策略: `&seed={n*42}` 或 `&seed={n*42+100}` 用于重制）
- **稳定性差**：频繁出现 403/500/timeout。重试+等待(3s)通常可恢复。使用 wget 或 urllib，带完整 UA header。
- **替代来源**：Mixkit CDN `assets.mixkit.co/videos/{id}/{id}-720.mp4`（真实视频截帧，无 AI 缺陷，更稳定）

## Prompt 编写规则（定制版用）

- **基于标题具体场景**：描述画面细节而非抽象概念
- **每条 prompt 开头不同**：描述维度差异化（光线/人物/地点/动作）
- **避免通用模板**：不要 "AI technology concept" 这种万能词
- **中文地名/人名**：用英文表达（"White House" "China"）
- **风格后缀可选**：newspaper illustration / documentary photo / cinematic / flat illustration

## 人脸变形规避（重要）

Pollinations AI 在生成正面人脸时经常出现扭曲/多眼/不对称等问题。**策略：**

- **优先选无人的场景**：用建筑/风景/静物代替有人场景
- **"no people" 关键词**：prompt 末尾加 `, no people, empty scene`
- **背影/侧面可接受**：如果必须有人，用背影或极侧角度
- **人群用远景**：小比例背景人物不会触发脸部变形
- **真实照片替代**：外交会面/名人新闻等必须有人脸的用 Mixkit 真实素材或真实新闻报道照片
- **正面特写避免**：永远不要用 "close-up portrait" "a man smiling" 等提示

### Prompt 示例

| 原始（可能崩脸） | 改进（无脸） |
|---|---|
| A doctor checking medicine | A hospital pharmacy with medicine bottles on shelves, clean lighting, no people |
| Customers eating at hotpot restaurant | Interior of a restaurant with steam rising, warm lighting, empty tables |
| A scientist working in lab | A chemistry laboratory with glass equipment and blue liquid, no people |
| Movie star at premiere | Movie theater screen with red curtain and empty seats, dramatic spotlight |

## 质量监控清单

- **脚本执行状态** — `cronjob list` 看 `last_status`
- **图片数量** — `ls archive/img_YYYYMMDD/*.jpg | wc -l`（daily=10，weekly=5）
- **图片大小** — 每张 50KB+
- **内容匹配度** — vision 工具抽检 3-5 张

## 注意事项

1. **日期必须匹配** — 脚本按当天日期找文件
2. **周六 weekly 不在 cron 中** — 周六 weekly 新闻稿需手动跑脚本
3. **脚本是幂等的** — 重复运行会覆盖已有图片
4. **Gateway 启动依赖** — cron scheduler 在 Hermes gateway 启动后才激活（gateway 09:01 启动）
5. **配图质量瓶颈** — Pollinations keyword_map 覆盖有限，未命中关键词时 fallback 生成通用图。改进：人工跑定制版，或扩充 keyword_map

## 已知问题

- **keyword_map 覆盖不足**：未命中的新闻 fallback 到通用 tech 模板（如"中融国际信托破产"→科技隧道图）
- **解决方案**：新闻稿出稿后跑定制版脚本，人工验证后替换