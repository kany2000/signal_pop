---
name: signal-pop-pipeline
description: Signal Pop (隔天信号弹) 新闻管道维护技能。覆盖 RSS 抓取 → 过滤 → 脚本生成 → TTS → 发布的全流程常见问题修复与最佳实践。
tags:
  - signal-pop
  - news-pipeline
  - rss
  - content-filtering
  - chinese-nlp
category: devops
---

# Signal Pop 新闻管道维护

## 管道架构

```
fetch_news.py → filter_news.py → generate_script.py → tts_mimo.py → 发布
     ↓              ↓                ↓               ↓
  RSS源抓取      去重/分类/清洗    播报文本生成      MiMo TTS音频
```

## 常见问题与修复

### 1. HTML 实体未解码 (`&nbsp;`, `&amp;`, `&lt;` 等)

**症状**：生成脚本中出现 `作者&nbsp;|&nbsp;王晗玉`

**修复** (`fetch_news.py`)：
```python
import html
summary = html.unescape(summary)  # 在 re.sub 之后调用
```

### 2. 摘要硬截断导致半句残缺

**症状**：`"此次融资将.."`、`"过..."`

**修复** (`fetch_news.py`) - 智能截断在句号处：
```python
if len(summary) > 300:
    match = re.search(r'[。！？.!?]', summary[:300])
    if match:
        summary = summary[:match.end()]
    else:
        summary = summary[:300]
```

### 3. 垃圾内容混入（体育/娱乐/财经行情/博彩/英文标题）

**症状**：FIFA 世界杯、电影票房、美元指数/期铜价格、博彩广告、未翻译英文标题

**修复** (`filter_news.py`) - 多层过滤：

```python
SPAM_KEYWORDS = [
    # 体育赛事
    "世界杯", "FIFA", "欧冠", "英超", "NBA", "裁判", "进球", "比分", "赛程",
    # 娱乐八卦
    "票房", "电影", "上映", "玩具总动员", "漫威", "迪士尼",
    # 财经行情（非新闻类）
    "美元指数", "期铜", "收盘", "涨停", "北向资金", "LME", "WTI",
    # 博彩/广告
    "点击浏览", "即时更新", "精彩进球", "万勿错过", "竞猜", "赔率",
]

def is_spam(title, summary):
    text = (title + " " + summary).lower()
    for kw in SPAM_KEYWORDS:
        if kw.lower() in text:
            return True
    # 检测全英文/高英文比例标题
    if re.match(r'^[A-Za-z\s\.,\-\'\?]+$', title.strip()) and len(title) > 5:
        return True
    words = title.split()
    english_words = sum(1 for w in words if re.match(r'^[A-Za-z\.\,\-]+$', w))
    if len(words) >= 4 and english_words / len(words) > 0.7 and not re.search(r'[\u4e00-\u9fff]', title):
        return True
    return False
```

### 4. 繁体中文未转简体（BBC 中文 RSS）

**修复** (`filter_news.py`) - 使用 OpenCC：
```bash
pip install opencc-python-reimplemented
```
```python
from opencc import OpenCC
cc = OpenCC('t2s')
title = cc.convert(title)
summary = cc.convert(summary)
```

## 运行顺序

```bash
cd /home/kan/signal_pop
python3 src/fetch_news.py      # 抓取 → data/raw_feed.json
python3 src/filter_news.py --mode daily --top 10  # 过滤 → data/filtered_news.json
python3 src/generate_script.py daily              # 生成 → archive/signal_pop_daily_YYYYMMDD.txt
```

## ⚠️ 视频生产流水线（完整流程）⚠️

### 日期铁律

**新闻周日做 → 周一发布 → 视频标注周一日期**
- `DATE` (新闻稿日期、配图目录、TTS文件) = 制作日
- `PUB_DATE` (视频叠文字、封面) = 制作日 + 1天 = 发布日
- Build脚本自动计算 `PUB_DATE = DATE + 1`，无需手动改

### 生产步骤

```bash
cd /home/kan/signal_pop

# 1. 新闻稿确认 → 检查时政人物头衔（当前2026: 特朗普是现任总统，非"前总统"）
less /home/kan/shared/signal_pop/archive/signal_pop_daily_YYYYMMDD.txt

# 2. 配图 — 两条路径
#    路径A（默认/自动）: Pollinations cron → 10张新闻配图
#       cron job "signal-pop-daily-images" (09:30 周日/二/四/五)
#       脚本: /home/kan/shared/signal_pop/scripts/gen_news_images.py
#       输出: archive/img_YYYYMMDD/01.jpg … 10.jpg
#
#    路径B（定制prompt, 手动）: gen_custom_images.py — 硬编码了today日期
#       使用前先改脚本内 today 变量
#       python3 /home/kan/shared/signal_pop/scripts/gen_custom_images.py
#       输出: archive/img_YYYYMMDD/01.jpg … 10.jpg
#
#    ⚠️ opening_bg.jpg 需单独生成（cron不生成开场图）:
#       python3 -c "
#       import urllib.request, urllib.parse
#       prompt = 'Wide shot of a modern TV news broadcasting studio...'
#       q = urllib.parse.quote(prompt)
#       url = f'https://image.pollinations.ai/prompt/{q}?width=1920&height=1080&nologo=true&seed=999'
#       headers = {'User-Agent': 'Mozilla/5.0', 'Referer': 'https://pollinations.ai/'}
#       req = urllib.request.Request(url, headers=headers)
#       with urllib.request.urlopen(req, timeout=120) as r:
#           data = r.read()
#       with open('archive/img_YYYYMMDD/opening_bg.jpg', 'wb') as f:
#           f.write(data)
#       print(f'OK {len(data)} bytes')
#       "

# 3. TTS — 注意必须传.wav扩展名，否则覆盖bug
python3 src/tts_mimo.py "$(cat /home/kan/shared/signal_pop/archive/signal_pop_daily_YYYYMMDD.txt)" \
  --female \
  --output output/daily/signal_pop_daily_YYYYMMDD.wav \
  --srt output/daily/signal_pop_daily_YYYYMMDD.srt

# 4. 修改 build_daily_video.py 中的 DATE 变量为当天日期，然后构建视频
#    编辑 scripts/build_daily_video.py 第6行 DATE = "YYYYMMDD"
#    ⚠️ build_daily_video.py 写封面为 cover_{DATE}.png → 需手动 cp 为 video_{DATE}.png
#       或先修脚本 HER2HOME_COVER 路径
python3 scripts/build_daily_video.py
# 输出: output/daily/signal_pop_daily_YYYYMMDD_v4.mp4
# 自动复制到: /home/kan/shared/her2home/video_YYYYMMDD.mp4 + cover_YYYYMMDD.png
# ⚠️ cover_YYYYMMDD.png 仅为开场帧截图，不能做视频封面

# 5. 生成模板封面（强制 — 非视频帧截图）
#    封面设计：深蓝渐变背景 + 标题「隔天信号弹」+ 右上日期 + 10条编号新闻列表
#    参考 skill 内「封面生成流程」模板规则。用 NotoSansCJK 字体。
#    输出 /home/kan/shared/her2home/video_YYYYMMDD.png（1920×1080 PNG）
#    ⚠️ 文件名必须 video_YYYYMMDD.png（auto_publish.py 按 video_ 同名查找）
#    ⚠️ 封面可以且应该和开场图不同

# 6. 生成元数据 JSON
#    /home/kan/shared/her2home/video_YYYYMMDD.json

# 7. 手动运行自动分发（一次性，不要设cron）
cd /home/kan/shared/social-auto-upload && python3 auto_publish.py
# ⚠️ 只跑一次 — 不要设周期性 cron！用户明确要求不要多次触发。
# ⚠️ 分发前必须清理：移走 her2home/ 旧视频文件 + 清理 .publish_state.json
#    见下方「分发前准备」节。
# ⚠️ 抖音在无头服务器需设置环境变量：
export DOUYIN_COOKIE_AUTH_HEADLESS=true
# ⚠️ 如果报 Playwright 浏览器缺失，先查看 sau 用哪个包再装：\n#    pip list | grep -iE \"playwright|patchright\"\n#    若用 patchright → python3 -m patchright install chromium\n#    若用 playwright  → python3 -m playwright install chromium
```

### 关键坑点

| 问题 | 根因 | 修复 |
|------|------|------|
| TTS输出文件覆盖 | `--output`没传`.wav`后缀 → JSON覆盖了WAV | 必须 `--output xxx.wav` |
| 渐变画成纯黑 | `draw.rectangle(fill=(0,0,0,α))`画在RGB图上，α被忽略 | 改用 `Image.alpha_composite(RGBA层)` |
| 文字可读性差 | 浅色背景上白色文字看不清 | 9点阴影 `[(±1,0),(0,±1),(±1,±1),(0,2)]` |
| 开场图半黑 | 底部渐变遮住背景 | 渐变仅覆盖左半区域(0-960px) |
| 音画不同步 | proportional估算不准 | TTS返回每段`nframes/framerate`实际时长 |
| 日期标错 | 写了制作日而非发布日 | `PUB_DATE = DATE + 1` 自动计算 |
| 时政头衔错误 | 未核实人物现状 | **必须核查**：当前2026年特朗普是现任总统 |
| auto_publish 扫到旧视频而非新视频 | `.publish_state.json` 中旧视频标记了部分平台失败 → 脚本认为未完成 | 清理状态文件，只保留新 video_YYYYMMDD.mp4 的记录，或清空 `.publish_state.json` 的 `published` 字段重跑 |
| 新闻配图重复 | `keyword_map` 关键词跨条匹配 + URL 无 `seed` 参数 → Pollinations 返回相同图 | 已修：`seed={n*37}` + prompt 追加标题差异化剩余部分 |
| 封面用开场帧截图 | build_daily_video.py 复制开场帧到 `cover_*.png`，用户要求模板封面 | 新增 step 5：独立生成模板封面，不能用开场帧替代 |

### 新闻配图重复问题

**症状**：`gen_news_images.py` 生成的 05.jpg 和 08.jpg 是同一张图
**根因**：
1. `keyword_map` 中 "AI" 同时匹配了第5条(GPT-5)和第8条(欧盟AI调查)，返回相同prompt模板
2. Pollinations URL 没加 `seed` 参数 → 相同prompt返回相同图片
**修复**（已应用至 `gen_news_images.py`）：
- `build_prompt(title)` → `build_prompt(title, index)`，每条prompt追加标题中去除关键词后的剩余部分做差异化
- URL 追加 `&seed={n*37}`，确保相同prompt在不同seed下出不同图
- 脚本已检测已存在文件跳过，可删 `rm 05.jpg 08.jpg` 后重跑

### 封面生成流程（强制）

**封面 = 模板生成，非视频帧截图。** `build_daily_video.py` 复制开场帧到 `cover_*.png` 仅作为内嵌封面，**不能替代**视频封面。

```bash
# 正确封面生成步骤：
# 1. 先配齐 archive/img_YYYYMMDD/ 下 10张配图 + opening_bg.jpg
# 2. 运行 build_daily_video.py → 输出 video_YYYYMMDD.mp4 + cover_YYYYMMDD.png
# 3. 运行 gen_cover.py 生成模板封面（深蓝渐变+标题+10条新闻列表）
#    gen_cover.py 路径: （skill 内 scripts/gen_cover.py）
#    或手动写一个临时脚本，用 NotoSansCJK font 生成
# 4. 通过 cp/write 输出到 /home/kan/shared/her2home/video_YYYYMMDD.png
#    ⚠️ 文件名必须是 video_YYYYMMDD.png（auto_publish.py 按 video_ 同名查找）
#    build_daily_video.py 输出 cover_YYYYMMDD.png 不符合要求，需要手动重命名或复制
```

**封面模板规则**（`gen_cover.py` 或手写脚本遵守）：
- 1920×1080 16:9
- 背景：深蓝渐变 (`#0A1628` 起)
- 装饰：右上光晕、左下一角装饰线条
- 主标题：「隔天信号弹」白色粗体 + 蓝色描边
- 副标题：「Signal Pop · 每日硬核资讯」青色
- 右上角：日期 `YYYY.MM.DD` + 星期 + 期数
- 中部：10条新闻编号列表（蓝色圆圈编号 + 白色标题文字）
- 底部品牌行 + 发布信息
- 字体：NotoSansCJK-Bold / NotoSansCJK-Regular（`/usr/share/fonts/opentype/noto/`）

### 人脸/身体变形规避 + 场景类型差异化

配图prompt策略：
- **优先选无人物场景**（技术/经济/国内新闻都可做纯场景/设备/图表）
- 必须有人物时：避免正面人脸、避免全身站立（AI画下半身常上下半身错位）
- 人物prompt强制加 `, no people` 反向不够强 → 直接设计为无人物场景
- 外交/政治→建筑外景、会议室内景（无人）
- 社会新闻→场景环境（城市街景、医院、实验室，无人）
- 经济新闻→数据图表、工厂仓库、店面（无人）
- 科技新闻→实验设备、芯片微距、数据中心走廊（无人）
- 体育新闻→球场俯拍全景（小人物可接受，但vision检查变形）
- **⚡ 10张配图必须有各自不同的场景类型** — 不能多用「赛博隧道/数据中心走廊」风格
  - 反例：#4 AI素养教育、#7 仿生皮肤量产、#10 日元剧震 → 都用了蓝紫隧道风，被用户指出
  - 正例：教室·学校 · 工厂·机械臂 · 日元硬币·金融街天际线 · 球场俯拍 · 芯片微距 · 光伏农场
  - 人为分配：保证每张配图的「场景类别」不同（室内/室外/自然/城市/微距/图表...）
- `vision_analyze` **全量检查所有10张**确认：
  - ❌ 无人脸扭曲、五官错位
  - ❌ 无身体变形（上下半身移位、四肢比例失衡）
  - ❌ 无重复配图（关键词跨条命中+缺seed导致）
  - ❌ 无场景类型雷同（至少每张主场景不同）
  - 发现问题 → 删对应图，换无人物+不同场景的prompt重生成

### 开场/结束卡规则

- **开场图**：prompt `新闻播报直播间`，绿幕演播室实景，不与其他新闻图重复
- **结束卡**：**共用开场背景图**（opening_bg.jpg），压暗 + 标题 + 日期
- 开场/结束共用同一张「新闻播报直播间」背景，风格统一
- 开场首次生成存放到 `archive/img_YYYYMMDD/opening_bg.jpg`
- **结束卡标题文字固定为「下期见」**（非「明天见」—— 发布频率为周一/三/五，非每日，所以用「下期见」）
- 永久约束：`build_daily_video.py` 中 `draw.text((960, 580), "下期见", ...)` 已固化

### 排版规则（v4 最终版）

- 1920×1080，全屏铺底
- 左侧渐变遮罩（alpha 255→0 左半960px + 残余60→0 右半960px）
- 文字：分类标签(带底色) + 粗体标题 + 正文(3行) + 页码 + 来源
- 正文：双层阴影（8方向 + 下偏移9点），fill=(0,0,0,100)
- 页码：`2/10` 格式，右下角
- 底部栏：`隔天信号弹 · YYYY.MM.DD` 左下 + `n/10` 右下
- 日期用 `PUB_DATE_SHORT`（发布日）
- emoji不可用（PIL不支持→替代为金色圆环+实心圆）

### Patchright/Palywright 浏览器未安装（前置检查）

**`sau` 用 `patchright`（非 `playwright`）** — 两个包各自的 chromium 版本不同：
- `playwright 1.60.0` → `chromium-1223`
- `patchright 1.58.2` → `chromium-1208`（`sau` 实际使用的版本）

**症状**：`auto_publish.py` 报错：
```
BrowserType.launch: Executable doesn't exist at /home/kan/.cache/ms-playwright/chromium-1208/chrome-linux64/chrome
Looks like Playwright was just installed or updated.
```

**注意**：先查 `sau` 用的是哪个包：
```bash
pip list | grep -iE "playwright|patchright"
# patchright     1.58.2   ← sau 用这个
# playwright     1.60.0   ← 全局装的新版，版本不同
```
→ 新版 `playwright install chromium` 装的是 `chromium-1223`，但 `sau` 需要 `chromium-1208`。

**修复**（只需跑一次）：
```bash
# 1. 查看 sau 用的是 patchright 还是 playwright
pip show patchright | grep Version

# 2. 用对应的包名安装浏览器
#    如果 sau 用 patchright:
python3 -m patchright install chromium
#    如果 sau 用 playwright:
python3 -m playwright install chromium

# 3. 验证
ls -la /home/kan/.cache/ms-playwright/chromium-*/chrome-linux64/chrome
# 应该有文件

# ⚠️ playwright install 装的是新版 chromium（v1223+），
#    但 patchright 1.58.x 需要 v1208。千万别混用！
#    `pip install playwright && python3 -m playwright install chromium`
#    不会修好 patchright 的报错！
```

### 抖音无头服务器 Missing X Server

**症状**：
```
ERROR:ui/ozone/platform/x11/ozone_platform_x11.cc:257] Missing X server or $DISPLAY
The platform failed to initialize.  Exiting.
```

**根因**：抖音 `cookie_auth()` 函数默认**非无头**启动 Chrome（`headless=False`），因为"抖音无头会撞反爬墙→content/upload 跳登录→误判 cookie 失效"。但在无 X Server 的 headless 服务器上，这条策略直接导致 Chrome 无法启动。

**修复**：
```bash
# 设置环境变量让 cookie_auth 走无头模式
export DOUYIN_COOKIE_AUTH_HEADLESS=true

# 然后运行分发
python3 auto_publish.py
```

该环境变量在 douyin_uploader/main.py 中已内置支持：
```python
use_headless = os.environ.get("DOUYIN_COOKIE_AUTH_HEADLESS", "").lower() in ("1", "true", "yes")
```

**折衷**：强制无头后抖音可能误判 cookie 失效（间歇性），但至少不会崩溃。如果 cookie 被判定无效，需在有桌面的机器上跑 `sau douyin login --account her2home` 重新扫码。

### Chrome/Playwright 浏览器缺失替代方案（CDN 超时备用）

当 `python3 -m patchright install chromium` 下载 CDN 超时（国内服务器常见）：
```bash
# 方案1：用系统已安装的 Chrome 做 symlink
# 先查系统 Chrome 路径
which google-chrome chromium chromium-browser
# 预期: /opt/google/chrome/chrome

# 创建 patchright 期望的目录结构并 symlink
# 先查正确的版本号目录（从报错或 ls ~/.cache/ms-playwright/）
ls ~/.cache/ms-playwright/
mkdir -p ~/.cache/ms-playwright/chromium-1208/chrome-linux64
ln -sf /opt/google/chrome/chrome ~/.cache/ms-playwright/chromium-1208/chrome-linux64/chrome

# 验证
/opt/google/chrome/chrome --version
```

**注意**：版本号 (`chromium-1208`) 随 `patchright` 版本变化。从报错信息或 `ls ~/.cache/ms-playwright/` 提取即可。

**先确定 `sau` 用哪个包**：
```bash
pip list | grep -iE "playwright|patchright"
# → 用对应的包名叫 `.cache/ms-playwright/chromium-XXXX/`

### auto_publish.py YouTube 特殊处理

YouTube CLI 不支持 `--schedule`。`auto_publish.py` 已内置逻辑：
- YouTube → `--visibility private`（私密发布，手动改公开+设定时）
- 其他平台 → `--schedule YYYY-MM-DD HH:MM`

YouTube Cookie 过期处理：
```bash
sau youtube login --account her2home  # 需有桌面环境的机器扫码
```

## 关键文件位置

- 源码：`/home/kan/signal_pop/src/`
- 数据：`/home/kan/signal_pop/data/`
- 输出：`/home/kan/signal_pop/output/daily/`, `output/weekly/`
- 配置：环境变量 `MINIMAX_API_KEY`, `MINIMAX_BASE_URL`

## 多平台自动分发组件 ✅ 实战验证 (2026-07-01)

- **部署位置**：`/home/kan/shared/social-auto-upload/`
- **核心脚本**：`scripts/auto_publish.py` (见本 skill `scripts/` 目录) — 扫描 `/home/kan/shared/her2home/`，读取同名 `.json` 元数据，**顺序分发**到已认证平台，去重记录 `.publish_state.json`
- **登录脚本**：`login_all_platforms.sh` — 一键登录 4 平台 (首次扫码，cookie 持久化)
- **CLI 方式**：`sau douyin upload --account her2home --file <video> --title <title>` 等
- **实战状态 (2026-07-01 实测)**：
  - **B站 ✅** — 定时发布正常，tid=249 (科技/数码)
  - **快手 ✅** — 需 `--headless` 参数，定时发布正常
  - **YouTube ❌** — Cookie 过期，**需有桌面环境的机器跑 `sau youtube login --account her2home` 扫码更新** (headless 无法登录，报错 Missing X server)
  - **抖音 ⏳** — 需 Windows 有头模式扫码登录 `sau douyin login --account her2home`
  - **小红书 ⏳** — 未测试
- **Cron 状态**：暂停 (人工触发)，视频生成后手动跑 `python auto_publish.py`

### 关键坑点记录 (2026-07-01 实战)\n- **Playwright 浏览器缺失**：报错 `Executable doesn't exist at ... chromium-1208` → 修复：**`patchright install chromium`** (不是 `playwright install`，本项目用 patchright)\n- **YouTube CLI 不支持 `--schedule`** — 仅支持 `--visibility {public,unlisted,private}`、`--playlist`、`--thumbnail`，定时需改用私有发布后手动改或在 Studio 设置\n- **auto_publish.py 用顺序上传** — 避免并行导致浏览器实例冲突 (已在 skill 脚本中修正)\n- **YouTube 登录必须有 X Server** — 无头服务器无法完成扫码登录，需有桌面环境的机器操作\n- **重试失败上传需清理状态文件** — 编辑 `/home/kan/shared/her2home/.publish_state.json` 删除对应视频条目，再跑 `python auto_publish.py`\n- **封面图必须 1920×1080 16:9** — 实测 600×338 会被拉伸模糊，已编写 PIL 生成脚本 (见 `scripts/gen_cover.py`)\n\n### 实战成功的 sau 命令模板 (2026-07-01)\n```bash\n# B站 (支持 --schedule)\nsau bilibili upload-video --account her2home \\\n  --file /home/kan/shared/her2home/video_20260701.mp4 \\\n  --title \"隔天信号弹 7.01｜标题\" \\\n  --desc \"简介...\" \\\n  --tags \"隔天信号弹,科技资讯,AI,新闻\" \\\n  --tid 249 \\\n  --schedule \"2026-07-02 14:00\"\n\n# 快手 (需 --headless，支持 --schedule)\nsau kuaishou upload-video --account her2home \\\n  --file /home/kan/shared/her2home/video_20260701.mp4 \\\n  --title \"隔天信号弹 7.01｜标题\" \\\n  --desc \"简介...\" \\\n  --tags \"隔天信号弹,科技资讯,AI,新闻\" \\\n  --thumbnail /home/kan/shared/her2home/video_20260701.png \\\n  --headless \\\n  --schedule \"2026-07-02 14:00\"\n\n# YouTube (不支持 --schedule，用 --visibility private 后手动改)\nsau youtube upload-video --account her2home \\\n  --file /home/kan/shared/her2home/video_20260701.mp4 \\\n  --title \"隔天信号弹 7.01｜标题\" \\\n  --desc \"简介...\" \\\n  --tags \"隔天信号弹,科技资讯,AI,新闻\" \\\n  --visibility private \\\n  --headless\n```

## Signal Pop 配图规则 (强制)

1. **所有配图必须 16:9 横图** (1920×1080 或等比) — BlazeAPI 生成时必须指定 `aspect_ratio=16:9`，禁止 1:1
2. **每期必须不同** — 禁止复用旧封面/配图，每次生成新图
3. **成品保存至共享文件夹** `/home/kan/shared/` (对应 http://10.10.10.30:8080/) 按项目分目录
4. **封面命名规范**：`video_YYYYMMDD.png` (auto_publish.py 按 video 同名查找，`cover_*.png` 会被跳过)
5. **Watermark/logo**：150×150 严格放右下角 (见 memory "YouTube desc no `<>` allowed")

### 新闻配图生成（Pollinations AI，免费无Key）

- **脚本**：`/home/kan/shared/signal_pop/scripts/gen_news_images.py` — 读取 `archive/signal_pop_daily_YYYYMMDD.txt`，解析10条新闻标题，为每条生成1280×720配图，保存到 `archive/img_YYYYMMDD/`
- **Cron**：`signal-pop-daily-images` (09:00 周一三五，新闻稿出后一小时)
- **技术细节**：[references/pollinations-ai.txt](references/pollinations-ai.txt) — 必须带 `User-Agent` + `Referer` 头，否则403
- **⚠️ 重复图坑**：相同 prompt 不加 `seed` → Pollinations 返回同图。`keyword_map` 关键词可能跨条命中致多条同prompt。**修**：URL 加 `&seed={n*37}` + `build_prompt(title, index)` 每条追加标题差异化部分
- **免费替代方案**：Bing Image Creator (~15次/天)、Playground AI (500张/天)、Leonardo.ai (150 tokens/天)、Hugging Face Spaces

## 视频命名规范 (自动分发要求)

- 视频：`video_YYYYMMDD.mp4`
- 封面：`video_YYYYMMDD.png`
- 元数据：`video_YYYYMMDD.json` (含 title、tags、description、schedule_time)
- 放入 `/home/kan/shared/her2home/` 目录
- 运行 `python auto_publish.py` 自动分发

## 多平台自动分发 (social-auto-upload)

### 架构
```
马小v出片 → /home/kan/shared/her2home/video_xxx.mp4 + .png + .json
                ↓
         cron (10:30/16:30) 扫描
                ↓
         auto_publish.py 并行分发
                ↓
    ┌─────┬─────┬─────────┬────────┐
    ↓     ↓     ↓         ↓
  抖音   B站   小红书     快手
  定时发布
```

### 部署路径
- 仓库：`/home/kan/shared/social-auto-upload/` (13k⭐ dreammis/social-auto-upload)
- CLI：`sau douyin|bilibili|xiaohongshu|kuaishou ...`
- 登录脚本：`/home/kan/shared/social-auto-upload/login_all_platforms.sh` (首次扫码，cookie 持久化)
- 分发脚本：`/home/kan/shared/social-auto-upload/auto_publish.py`

### 分发脚本逻辑 (auto_publish.py)
1. 扫描 `/home/kan/shared/her2home/*.mp4`
2. 匹配同名 `.png/.jpg` (封面) + `.json` (元数据)
3. 读取 `.publish_state.json` 去重 — **同一文件名绝不重复上传**
4. 并行 `sau` 上传 4 平台 (含 `--schedule "次日 08:30"`)
5. 成功写入状态文件，失败下轮重试

### 元数据 JSON 模板
```json
{
  "title": "隔天信号弹 6.28｜标题",
  "desc": "简介内容...",
  "tags": "隔天信号弹,AI,科技",
  "schedule": "2026-06-29 08:30"   // 选填，默认次日 08:30
}
```

### auto_publish.py 旧视频污染问题

**症状**：`auto_publish.py` 总是重试旧的 `test_video_*.mp4` 或 `video_20260627.mp4`，不处理当前期视频

**根因**：`.publish_state.json` 中旧视频有部分平台标记失败（如抖音 `false`），且旧 `.mp4` 文件物理存在于 `her2home/` 目录中 → `find_new_videos()` 认为它们未发布完，优先重试

**修复**（两步缺一不可）：
```bash
# 1. 移走旧视频文件（auto_publish 扫描所有 .mp4）
mkdir -p /home/kan/shared/her2home/archive_old
mv /home/kan/shared/her2home/video_2026*.mp4 /home/kan/shared/her2home/archive_old/
mv /home/kan/shared/her2home/video_2026*.png /home/kan/shared/her2home/archive_old/
mv /home/kan/shared/her2home/video_2026*.json /home/kan/shared/her2home/archive_old/

# 2. 清理 .publish_state.json，只保留本期
#    或直接写入仅含本期 video 的记录
```

**预防**：分发前确认 `her2home/` 目录只有本期文件。旧视频集中移入 `archive_old/` 子目录。

### 分发策略（强制：仅手动一次性触发）

- 虾小图产出新闻稿：08:00-08:30
- 视频生成：配图→TTS→build_daily_video.py
- **手动运行 `python auto_publish.py` 一次性分发**
- **绝对不要设周期性 cron** — 用户明确要求不能多次触发
- 如果上传中途失败（如缺 X Server 或 Playwright 未装），按下方「失败修复」步骤处理

### 分发前准备（防 auto_publish 扫到旧视频）

`auto_publish.py` **扫描 `her2home/` 下所有 `.mp4` 文件**，不区分新旧。旧视频若状态中标记部分平台失败，会挡住新视频。

**分发前执行（每次）**：

```bash
cd /home/kan/shared/her2home

# 1. 移走所有旧视频/封面/元数据（只留本期 YYYYMMDD）
mkdir -p archive_old
mv video_20260*.mp4 video_20260*.png video_20260*.json cover_*.png cover_*.jpg test_*.mp4 test_*.png test_*.json archive_old/ 2>/dev/null

# 2. 验证只剩本期文件
ls -la *.mp4 *.png *.json
# ✅ 应该只有: video_YYYYMMDD.mp4 + .png + .json

# 3. 清理 .publish_state.json，只保留本期记录
#    写入内容:
#    {"published": {"video_YYYYMMDD.mp4": {"time": "…","platforms": {"bilibili": true}}}}
```

**失败修复（缺一不可）**：
1. 移走旧文件 → `mkdir -p archive_old && mv old_files archive_old/`
2. 清理 `.publish_state.json` 中除本期外的所有条目
3. 确保 Playwright 浏览器已装（见下方）
4. 抖音设置 `export DOUYIN_COOKIE_AUTH_HEADLESS=true`
5. 重新跑 `python3 auto_publish.py`
6. 多次失败仍不通 → 单独看小节「Playwright 浏览器缺失」+「抖音无头服务 Missing X Server」

---

### OpenMontage 评估参考 (2026-06-26)

OpenMontage (calesthio/OpenMontage, 22k⭐, AGPL-3.0) 是开源 agentic 视频制作系统，与 Signal Pop 高度相关：

- **核心管道**: `documentary-montage` (新闻蒙太奇)、`hybrid` (混合素材+生成，对标 HyperFrames)、`clip-factory` (长切短)、`talking-head` (口播)
- **工具覆盖**: 免费素材直连 (Pexels/Pixabay/Archive.org)、CLIP 语义检索、多渲染引擎 (HyperFrames/Remotion/FFmpeg)、专业级动态字幕、TTS 多提供商
- **架构对齐**: Executive Producer 编排 + checkpoint 审批 + 质量门控 + 预算控制 + 技能复用
- **已 clone 到**: `/home/kan/shared/OpenMontage/` 供团队现学现用
# 查看过滤后
cat data/filtered_news.json | jq '.[] | {title, category, summary: .summary[:80]}'

# 查看最新脚本
cat output/daily/signal_pop_daily_latest.txt
```