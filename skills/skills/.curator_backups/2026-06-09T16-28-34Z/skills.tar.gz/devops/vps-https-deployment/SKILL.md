---
name: vps-https-deployment
description: Deploy web services on a VPS with custom domain + HTTPS — options comparison (nginx+acme.sh, Caddy, 1Panel, Cloudflare Tunnel), step-by-step guides, SSL/cert lifecycle.
platforms: [linux]
requires: [docker, docker-compose, root-ssh]
---

# VPS HTTPS Deployment

Deploy a web service (Halo blog, any Docker app) on a VPS with HTTPS and custom domain. Covers all major approaches with tradeoffs.

## Approach Comparison

| Approach | Components | Effort | SSL Mgmt | Best For |
|---|---|---|---|---|
| **nginx + acme.sh** | nginx (反代) + acme.sh (证书) | 中 | 手动配 cron 续期 | 熟悉 Linux，要最大控制权 |
| **Caddy** | Caddy 一个 | 低 | 自动 | 追求简单，一个工具搞定 |
| **1Panel** | Web 面板应用商店 | 最低 | 面板点几下 | 新手友好，还要管理数据库/文件 |
| **Cloudflare Tunnel** | cloudflared Docker + CF 面板 | 低 | 自动（CF 托管） | 无公网 IP 或不想开端口 |

**Conceptual distinction (critical):** ACME client (acme.sh/certbot) only **issues certificates** — it does NOT serve web traffic. nginx/Caddy is the **web server** that listens on 80/443, terminates HTTPS, and reverse-proxies to the backend. These are complementary, not alternatives. Caddy is special because it bundles both roles. 1Panel abstracts both behind a GUI.

## User Preference: Step-by-Step From Scratch

This user prefers **complete, copy-pasteable commands** starting from zero (not assuming prior steps done). Always include:
- Exact SSH command with IP and password reminder
- Verification commands after each step (`curl`, `systemctl status`)
- The conceptual WHY behind each tool choice
- DNS record configuration steps (what type, what value)
- Firewall open commands (especially 80/443 for cloud security groups)

When giving multiple options, lead with a comparison table and recommendation.

---

## Approach 1: nginx + acme.sh

### 1. SSH & Prerequisites

```bash
ssh root@<VPS_IP>
# install nginx
apt update && apt install -y nginx
systemctl start nginx && systemctl enable nginx
```

### 2. Install acme.sh

```bash
curl https://get.acme.sh | sh -s email=your-email@example.com
# source ~/.bashrc or re-login after install
```

### 3. Configure nginx HTTP Reverse Proxy

```bash
cat > /etc/nginx/sites-available/service << 'EOF'
server {
    listen 80;
    server_name your.domain.com;
    location / {
        proxy_pass http://127.0.0.1:SERVICE_PORT;  # e.g. 8090 for Halo
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
EOF

ln -sf /etc/nginx/sites-available/service /etc/nginx/sites-enabled/
rm -f /etc/nginx/sites-enabled/default
nginx -t && systemctl reload nginx
```

Add DNS A record before proceeding: `your.domain.com → <VPS_public_IP>`

### 4. Issue SSL Certificate

```bash
# HTTP mode (nginx already running with domain)
acme.sh --issue -d your.domain.com --nginx

# or standalone mode (temporarily stops other services on port 80)
# acme.sh --issue -d your.domain.com --standalone
```

### 5. Install Certificate & Enable HTTPS

```bash
mkdir -p /etc/nginx/ssl

acme.sh --install-cert -d your.domain.com \
  --key-file /etc/nginx/ssl/domain.key \
  --fullchain-file /etc/nginx/ssl/domain.crt \
  --reloadcmd "systemctl reload nginx"

# Update nginx config for HTTPS
cat > /etc/nginx/sites-available/service << 'EOF'
server {
    listen 80;
    server_name your.domain.com;
    return 301 https://$server_name$request_uri;
}

server {
    listen 443 ssl http2;
    server_name your.domain.com;
    ssl_certificate /etc/nginx/ssl/domain.crt;
    ssl_certificate_key /etc/nginx/ssl/domain.key;
    location / {
        proxy_pass http://127.0.0.1:SERVICE_PORT;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
EOF

nginx -t && systemctl reload nginx
```

### 6. Firewall

```bash
ufw allow 80/tcp
ufw allow 443/tcp
```

**Cloud security group** must also allow 80 and 443 (not just OS firewall).

### 7. Auto-renew (automatic with acme.sh)

```bash
crontab -l | grep acme  # should show daily renewal job
```

---

## Approach 2: Caddy (All-in-One)

One tool replaces nginx + acme.sh:

```bash
apt install -y debian-keyring debian-archive-keyring
curl -1sLf 'https://dl.cloudsmith.io/public/caddy/stable/gpg.key' | gpg --dearmor -o /usr/share/keyrings/caddy-stable-archive-keyring.gpg
curl -1sLf 'https://dl.cloudsmith.io/public/caddy/stable/debian.deb.txt' | tee /etc/apt/sources.list.d/caddy-stable.list
apt update && apt install caddy

# Config — just domain + backend
cat > /etc/caddy/Caddyfile << 'EOF'
your.domain.com {
    reverse_proxy localhost:SERVICE_PORT
}
EOF

systemctl restart caddy
```

Caddy auto-issues Let's Encrypt certs, auto-HTTPS, auto-renew, auto-HTTP/2. No extra steps.

To switch from Caddy to another solution:
```bash
systemctl stop caddy && systemctl disable caddy
apt remove --purge -y caddy && rm -rf /etc/caddy
# verify 80/443 released
ss -tlnp | grep -E ':80 |:443 '
```

---

## Approach 3: 1Panel (GUI Panel)

### Install 1Panel

```bash
bash <(curl -sSL https://linuxmirrors.cn/1panel.sh)
# OR official:
# curl -sSL https://resource.fit2cloud.com/1panel/package/quick_start.sh -o quick_start.sh && bash quick_start.sh
```

During install: set port (default 9999), username, password. Save these.

### Post-install Steps in Web UI

1. Login at `http://<VPS_IP>:9999`
2. **App Store** → Install **OpenResty** (nginx wrapper)
3. **App Store** → Install **MySQL** first (Halo depends on it — DB dropdown will be empty without it)
4. (Optional) **Database** tab → Create a new database `halo`, charset `utf8mb4`
5. **App Store** → Search **Halo** → One-click deploy
6. **Websites** → Add website:
   - Domain: `your.domain.com`
   - Type: **Reverse Proxy**
   - Target: `http://localhost:8090` (or whatever port your service uses)
   - Enable HTTPS → **Auto-apply certificate**
7. If Let's Encrypt times out (China VPS), switch cert provider to **TrustAsia**:
   - **Websites** → Certificate management → ACME account → Provider → **TrustAsia**
8. Done — no config file editing needed

### Uninstall 1Panel

```bash
# Use the uninstall script from the panel's install directory
# Typically: /opt/1panel/1panel uninstall
```

---

## Approach 4: Cloudflare Tunnel

See `cloudflare-tunnel` skill for full details. TL;DR:

- No open ports needed (cloudflared connects outbound)
- Auto-HTTPS via Cloudflare
- Must configure DNS through Cloudflare (orange cloud proxied)
- Domain must be on Cloudflare's NS

---

## Migration (Moving from One VPS to Another)

When migrating Halo blog (or similar) between servers:

### Option A: Halo Admin Export/Import

1. Old server: Admin → Tools → Export → download .zip
2. Old server: copy attachments (`scp` or `rsync`)
3. New server: Admin → Tools → Import → upload .zip
4. New server: restore attachments to same path

### Option B: Full MySQL + File Dump

```bash
# Old server: dump DB
docker exec <mysql-container> mysqldump -u root -p<PASS> <db_name> > backup.sql

# Old server: pack attachments
tar czf attachments-backup.tar.gz <attachments-dir>

# Transfer to new server
scp backup.sql attachments-backup.tar.gz root@<NEW_VPS_IP>:/root/

# New server: restore
cat /root/backup.sql | docker exec -i <mysql-container> mysql -u root -p<PASS> <db_name>
tar xzf /root/attachments-backup.tar.gz -C <attachments-dir>
```

### Option C: Official Halo Migration Tool

For cross-version migration (1.x → 2.x): see https://docs.halo.run

---

## DNS Configuration

When NOT using Cloudflare DNS (Caddy/native approach):

```
A record:  blog.yourdomain.com → <VPS_PUBLIC_IP>
```

Pre-create the DNS record before starting ACME challenge (cert issuance needs domain to resolve).

When using Cloudflare DNS:
```
CNAME:   blog.yourdomain.com → <tunnel-id>.cfargotunnel.com
Proxy:   ON (orange cloud)
```

---

## Troubleshooting

### "HTTP 502 Bad Gateway"

nginx: app not running or wrong `proxy_pass` port. Check `docker ps` and `curl localhost:SERVICE_PORT`.

### "Cert issuance failed — domain doesn't resolve"

DNS A record not propagated yet, or pointing to wrong IP. Check `dig +short your.domain.com`.

### "Port 80/443 already in use"

Another web server (nginx, Caddy, Apache) or 1Panel already bound. `ss -tlnp | grep ':80 '` to find PID.

### 1Panel install: "Could not resolve host"

Check URL spelling: `resource.fit2cloud.com` (not `fit2com.com`).

### 1Panel Halo deploy: database dropdown empty

**Symptom:** Halo install page shows "无数据" on submit button, DB dropdown has no selectable options.

**Fix:** MySQL must be installed **before** deploying Halo. Go to **App Store** → search **MySQL** → Install. After MySQL starts, return to Halo deploy — dropdown will show the MySQL instance.

### "Let's Encrypt ACME endpoint unreachable" (China VPS)

```
dial tcp 172.65.32.248:443: i/o timeout
```

Let's Encrypt's `acme-v02.api.letsencrypt.org` is often blocked from China-hosted VPS.

**Fix in 1Panel:**
1. **Websites** → Certificate management → ACME account settings
2. **Provider** → switch from **Let's Encrypt** → **TrustAsia**
3. Re-issue cert

**Fix for acme.sh (CLI):**
```bash
acme.sh --set-default-ca --server zerossl
acme.sh --issue -d your.domain.com --nginx
```

---

## Pitfalls

- **ACME client ≠ web server**: acme.sh only issues certs. You still need nginx/Caddy to serve and terminate HTTPS. Users often confuse these and ask "acme还需要nginx吗？" — explain the distinction.
- **Certificate algorithm: prefer ECC over RSA**: ECC/ECDSA (Prime256v1) gives smaller keys, faster handshake, modern browser support. Choose ECC in 1Panel cert settings or pass `--ecc` to acme.sh. Only fall back to RSA 2048 for legacy client compatibility.
- **DNS before ACME**: Domain A record must resolve to VPS IP before cert issuance.
- **Cloud security groups**: OS firewall (ufw) is not enough — cloud providers (AWS/Azure/阿里云) need port 80/443 opened in their security group separately.
- **Caddy → other**: Stop and remove Caddy before installing 1Panel or nginx, else port 80/443 conflict.
- **1Panel URL**: `fit2cloud.com` (not `fit2com.com`). Common typo.
- **Backup original configs**: Before modifying nginx/Caddy/1Panel configs, save originals.
- **SSH password auth**: This VPS (10.10.10.13) requires interactive password entry — can't use `sshpass`. Use `pexpect` for automation or provide copy-paste commands for the user.
- **`external-url` setting**: Update the app's own `external-url` config (e.g. `--halo.external-url=https://blog.yourdomain.com`) so generated links use the correct domain, not localhost.
