---
name: signal-pop-news-video-pipeline
description: End‑to‑end pipeline for generating news videos for Signal Pop (隔天信号弹), covering both the legacy free‑asset approach AND the new Google Flow + Veo 3.1 zero‑cost AI video workflow.
author: Hermes Agent
version: 2.0.0
license: MIT
---

# Signal Pop News Video Pipeline

Two approaches exist for generating video content. **Prefer Google Flow (2026)** — it's free, higher quality, and simpler to operate.

---

## Approach A: Google Flow + Veo 3.1 (Recommended, 2026)

**Cost: $0.** No API keys, no infrastructure, no ffmpeg.

Google Flow (labs.google/fx/tools/flow) is a unified AI creative studio that bundles video generation, image generation, and editing — all free with a Google account.

### Tools inside Flow

| Tool | Purpose | Free tier |
|------|---------|-----------|
| **Veo 3.1** | Video generation with native audio (dialogue + lip-sync + SFX + music) | 20 credits/clip (Fast) |
| **Nano Banana** | Image generation, character consistency, precise editing | Included in Flow |
| **Gemini Omni** | Multimodal input, conversational editing, script generation | Included in Flow |

### Free Credits
- 100 starter + 50 daily credits
- Veo 3.1 Fast = 20 credits → **2–3 clips/day free**
- Veo 3.1 Lite = 10 credits → **5 clips/day free**
- 1080p upscale: free; 4K upscale: 50 credits
- **No watermark** on free tier

### Clip limits
- Single generation: 4–8 seconds
- Extend via chaining (7s hops × up to 20) → ~148 seconds (~2.5 min)
- Quality degrades after 3–5 hops; plan accordingly

### Workflow for Signal Pop

1. **Plan + script via Gemini Omni** — Gemini Omni is the multimodal hub inside Flow. Feed it reference images, video clips, or text prompts. Use it to plan visual direction and generate narration script.
2. **Create character reference via Nano Banana** — Generate subject‑consistent images (presenter/avatar/scene). Output serves as **reference image** for Veo.
3. **Seed Veo 3.1 with reference images** — Upload Nano Banana output as the starting image for Veo 3.1. This gives character consistency across clips. Prompt describes motion/dialogue from the script segment.
4. **Extend/chain** clips for longer segments (7s hops, ≤20 hops)
5. **Dialogue lip-sync** — Veo 3.1 generates native audio from text prompt. Script text in the prompt → synchronized speech.
6. **Download** 720p/1080p output

### Limitations
- Single clip ≤ 8s (need chaining for longer)
- Custom audio upload not supported (use Flow's native audio)
- Requires Google account; no programmatic API (web UI only)
- No direct API for automated pipeline — human-in-loop for now

### Access
- URL: https://labs.google/fx/tools/flow
- Sign in with any Google account (free)
- Region-locked? Check FAQ at labs.google/fx/tools/flow/faq

---

## Approach B: Legacy Free-Asset Pipeline (Deprecated)

The original Pexels + MoviePy pipeline has been **superseded** by Approach A. Kept here for reference.

> The user switched to audio-only (MP3 + text script) as of 2026-05-13. See **`signal-pop-audio-only-pipeline`** for the current working configuration.

### Prerequisites
- Python 3.11+ with `pip`.
- Internet access for RSS feeds and Pexels API (optional).
- **Optional**: `ffmpeg`/`ffprobe` for real video assembly. If unavailable, the pipeline falls back to a placeholder silent audio and an empty MP4.

### Project Structure
```
signal_pop_project/
├─ src/
│  ├─ fetch_news.py          # RSS fetch & 48h filter (fixed feedparser attribute)
│  ├─ filter_news.py         # Keyword scoring filter
│  ├─ generate_script.py     # Offline script generator (no LLM API required)
│  ├─ match_assets.py        # Pexels search, downloads clips/images
│  ├─ tts.py                 # Generates silent placeholder audio via pydub
│  ├─ assemble_video.py      # Creates placeholder MP4 (fallback when ffmpeg missing)
│  └─ upload.py              # Stub upload metadata
├─ assets/
│  ├─ clips/   (downloaded video clips)
│  ├─ images/  (downloaded images)
│  └─ audio/   (combined.wav created by tts.py)
├─ data/
│  ├─ raw_feed.json
│  ├─ filtered_news.json
│  ├─ script.txt
│  └─ final.mp4
├─ scripts/run_all.sh        # Orchestrates the whole pipeline
├─ docs/signal_pop_architecture.html  # Architecture diagram (generated)
└─ requirements.txt
```

### Common Pitfalls (Legacy)
- **Missing `published_parsed` attribute** – fixed by patching `fetch_news.py`.
- **OpenAI/Large‑model API key not set** – replaced LLM call with offline generator.
- **`ffmpeg` not installed** – `assemble_video.py` now falls back to creating an empty MP4 so the pipeline never aborts.
- **Pexels API quota** – limit to one result per headline; failures are logged but do not stop the pipeline.

# References
- Google Flow landing: https://labs.google/fx/tools/flow
- Veo 3.1 model: https://deepmind.google/models/veo/
- Nano Banana (Gemini Image): https://deepmind.google/models/gemini-image/
- Google Flow FAQ: https://labs.google/fx/tools/flow/faq
