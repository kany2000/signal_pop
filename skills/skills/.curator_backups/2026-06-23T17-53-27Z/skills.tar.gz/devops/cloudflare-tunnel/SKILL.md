---
name: cloudflare-tunnel
description: Expose local web services to the internet via Cloudflare Tunnel — docker-compose integration, token auth, DNS setup, troubleshooting.
platforms: [linux]
requires: [docker, docker-compose]
---

## Cloudflare Tunnel — Expose Local Services

> Part of `vps-https-deployment` umbrella. For alternative approaches (nginx+acme.sh, Caddy, 1Panel), see that skill.

Expose any local web service (Docker container or bare-metal) to the public internet via Cloudflare's edge network. No open firewall ports needed. Works behind NAT, CGNAT, or residential ISPs that block port 80/443.

## Architecture

```
[Local Service] ← → [cloudflared] ← → [Cloudflare Edge] ← → [your-domain.com]
```

- **cloudflared** runs as a Docker container, connects outbound to Cloudflare
- Cloudflare routes public traffic through the tunnel to the local service
- Built-in HTTPS, CDN, and DDoS protection via Cloudflare

## Prerequisites

- Domain on Cloudflare (NS pointing to Cloudflare)
- Docker + Docker Compose on the local server
- Internet access from local server (outbound-only, no open ports needed)

## Setup

### 1. Create a Tunnel in Cloudflare Dashboard

```
https://one.dash.cloudflare.com/ → Access → Tunnels → Create a tunnel
```

- Name the tunnel (e.g., `my-service`)
- Choose deployment method: **Docker**
- Copy the token string (`eyJ...`) — this is the one-time credential

### 2. Add Cloudflared to docker-compose.yml

```yaml
services:
  # ... your existing service ...
  your-app:
    # ... your app config ...
    networks:
      - app_network

  cloudflared:
    image: cloudflare/cloudflared:latest
    restart: always
    networks:
      - app_network
    command: tunnel --no-autoupdate run --token ${CF_TUNNEL_TOKEN}
    depends_on:
      your-app:
        condition: service_healthy  # optional, ensures app is ready

networks:
  app_network:
```

### 3. Set the token in .env

```bash
# /path/to/project/.env
CF_TUNNEL_TOKEN=***   # ← paste your token here
```

### 4. Configure Public Hostname in Dashboard

After tunnel is created, add a route:

```
Public hostname: blog.yourdomain.com
Service:         http://your-app:PORT      # container name + internal port
```

Cloudflare auto-provisions DNS + SSL.

### 5. Start

```bash
cd /path/to/project
docker compose up -d
```

### 6. Verify

```bash
# Check tunnel status in dashboard (should show "Healthy")
# Or from the server:
docker compose logs cloudflared

# Check public access:
curl -sI https://blog.yourdomain.com
```

## docker-compose Patterns

### Service on same docker network (preferred)

Cloudflared and app share a compose network → use container name as hostname.

```yaml
cloudflared:
  command: tunnel --no-autoupdate run --token ${CF_TUNNEL_TOKEN}
  networks:
    - app_network   # same network as the app service
```

### Service on host port only

If you can't share a network, cloudflared can use `host.docker.internal` (Docker Desktop) or `host` network mode:

```yaml
cloudflared:
  network_mode: host
  command: tunnel --no-autoupdate run --token ${CF_TUNNEL_TOKEN}
  # Then uses: http://localhost:8090 in dashboard config
```

### Updating external-url of the app

If your app generates links (like a blog/CMS), update its `external-url` setting to the public domain so it generates correct URLs.

```
- --external-url=https://blog.yourdomain.com
```

## Working with Halo Blog (concrete example)

Halo is a Java-based blog platform running on Docker. Full docker-compose:

```yaml
services:
  halo:
    image: registry.fit2cloud.com/halo/halo:2.24.2
    restart: always
    depends_on:
      halodb:
        condition: service_healthy
    networks:
      halo_network:
    volumes:
      - ./halo2:/root/.halo2
    ports:
      - "8090:8090"
    command:
      - --spring.r2dbc.url=r2dbc:pool:mysql://halodb:3306/halo
      - --spring.r2dbc.username=root
      - --spring.r2dbc.password=${DB_PASSWORD}
      - --spring.sql.init.platform=mysql
      - --halo.external-url=https://blog.yourdomain.com

  halodb:
    image: mysql:8.1.0
    restart: always
    networks:
      halo_network:
    environment:
      - MYSQL_ROOT_PASSWORD=${DB_PASSWORD}
      - MYSQL_DATABASE=halo

  cloudflared:
    image: cloudflare/cloudflared:latest
    restart: always
    networks:
      - halo_network
    command: tunnel --no-autoupdate run --token ${CF_TUNNEL_TOKEN}
    depends_on:
      halo:
        condition: service_healthy

networks:
  halo_network:
```

Dashboard hostname config:
```
Service: http://halo:8090
```

## Troubleshooting

### Tunnel shows "Disconnected" / "Down"

```bash
# Check logs
docker compose logs cloudflared --tail=50

# Common causes:
# - Token expired (regenerate in dashboard)
# - No internet access from server (check curl google.com)
# - DNS resolution failure (check /etc/resolv.conf)
```

### 502 Bad Gateway

cloudflared can reach Cloudflare but not the local service.

```bash
# Is the app running?
docker compose ps

# Can cloudflared reach it? Enter the container:
docker compose exec cloudflared curl -s http://halo:8090/actuator/health  # Halo example
# Or use the actual service:port from dashboard config

# Check app logs
docker compose logs your-app --tail=30
```

### SSL / Mixed Content

- Cloudflare handles SSL termination automatically
- If your app generates absolute HTTP URLs, update its `external-url` to `https://`

### Token Redaction in Shell Output

The terminal tool may redact passwords/tokens as `***` in output. Use `od -c` to read raw bytes:

```bash
cat .env | od -c   # reveals actual characters
```

## Pitfalls

- **Token must be set before first `docker compose up`**, otherwise cloudflared won't start
- **`.env` file must be in the same directory as `docker-compose.yml`**, or referenced explicitly
- **`--no-autoupdate`** flag is recommended for Docker — cloudflared auto-update conflicts with container lifecycle
- **Service dependency**: always set `depends_on` with health condition so cloudflared doesn't start before the app is ready
- **Update `external-url`** in the app config to reflect the public domain, not localhost
- **Backup original files** before editing docker-compose.yml, nginx configs, or .env
- **`.xyz` domains face extra scrutiny** from Google AdSense — content quantity and quality become more important
