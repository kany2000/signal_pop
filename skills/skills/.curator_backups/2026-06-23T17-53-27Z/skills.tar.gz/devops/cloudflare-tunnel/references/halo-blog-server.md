# Halo Blog Server (10.10.10.13)

## Server Info
- Hostname: `halo`
- OS: Ubuntu 24.04 LTS
- SSH: root@10.10.10.13 / password: kan453245
- Docker: v28.5.1, Docker Compose v2.40.0
- IP: 10.10.10.13 (internal), 100.84.133.58 (Tailscale), 183.34.10.118 (public)
- Public domain: blog.c33.us.kg (Cloudflare DNS)
- AdSense ID: pub-5107852894366261 (in ads.txt)

## Running Services
- Halo blog on port 8090 (Docker, container name: halo-halo-1)
- MySQL 8.1.0 (Docker, container name: halo-halodb-1)
- Compose file: /root/halo/docker-compose.yml
- Halo data: /root/halo/halo2/
- MySQL data: /root/halo/mysql/

## AdSense Status
- Already configured with publisher ID pub-5107852894366261
- ads.txt exists at /root/halo/halo2/ads.txt
- The blog has ~15+ original posts about payment processing, tech, VPS, Docker
- Blog is suitable for AdSense content requirements

## Tunnel Status
- Cloudflare Tunnel integration added to docker-compose.yml
- .env template at /root/halo/.env (CF_TUNNEL_TOKEN placeholder)
- Token needs to be set by user from Cloudflare Zero Trust dashboard
- Dashboard hostname config: Service = http://halo:8090

## SSH Access Pattern (password auth)

```python
import pexpect

def run_remote(cmd, timeout=15):
    child = pexpect.spawn(f"ssh -o StrictHostKeyChecking=no root@10.10.10.13 '{cmd}'", timeout=timeout)
    child.expect('password:', timeout=10)
    child.sendline('kan453245')
    child.expect(pexpect.EOF, timeout=timeout)
    return child.before.decode() if isinstance(child.before, bytes) else str(child.before)
```

Notes:
- Install pexpect: `pip install pexpect` (inside the venv; --user won't work in a venv)
- The terminal tool may redact passwords as `***` in output — use `od -c` to verify raw content
