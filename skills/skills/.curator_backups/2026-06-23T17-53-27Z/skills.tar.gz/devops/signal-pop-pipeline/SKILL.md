---
name: signal-pop-pipeline
description: Signal Pop (隔天信号弹) 新闻管道维护技能。覆盖 RSS 抓取 → 过滤 → 脚本生成 → TTS → 发布的全流程常见问题修复与最佳实践。
tags:
  - signal-pop
  - news-pipeline
  - rss
  - content-filtering
  - chinese-nlp
category: devops
---

# Signal Pop 新闻管道维护

## 管道架构

```
fetch_news.py → filter_news.py → generate_script.py → tts_mimo.py → 发布
     ↓              ↓                ↓               ↓
  RSS源抓取      去重/分类/清洗    播报文本生成      MiMo TTS音频
```

## 常见问题与修复

### 1. HTML 实体未解码 (`&nbsp;`, `&amp;`, `&lt;` 等)

**症状**：生成脚本中出现 `作者&nbsp;|&nbsp;王晗玉`

**修复** (`fetch_news.py`)：
```python
import html
summary = html.unescape(summary)  # 在 re.sub 之后调用
```

### 2. 摘要硬截断导致半句残缺

**症状**：`"此次融资将.."`、`"过..."`

**修复** (`fetch_news.py`) - 智能截断在句号处：
```python
if len(summary) > 300:
    match = re.search(r'[。！？.!?]', summary[:300])
    if match:
        summary = summary[:match.end()]
    else:
        summary = summary[:300]
```

### 3. 垃圾内容混入（体育/娱乐/财经行情/博彩/英文标题）

**症状**：FIFA 世界杯、电影票房、美元指数/期铜价格、博彩广告、未翻译英文标题

**修复** (`filter_news.py`) - 多层过滤：

```python
SPAM_KEYWORDS = [
    # 体育赛事
    "世界杯", "FIFA", "欧冠", "英超", "NBA", "裁判", "进球", "比分", "赛程",
    # 娱乐八卦
    "票房", "电影", "上映", "玩具总动员", "漫威", "迪士尼",
    # 财经行情（非新闻类）
    "美元指数", "期铜", "收盘", "涨停", "北向资金", "LME", "WTI",
    # 博彩/广告
    "点击浏览", "即时更新", "精彩进球", "万勿错过", "竞猜", "赔率",
]

def is_spam(title, summary):
    text = (title + " " + summary).lower()
    for kw in SPAM_KEYWORDS:
        if kw.lower() in text:
            return True
    # 检测全英文/高英文比例标题
    if re.match(r'^[A-Za-z\s\.,\-\'\?]+$', title.strip()) and len(title) > 5:
        return True
    words = title.split()
    english_words = sum(1 for w in words if re.match(r'^[A-Za-z\.\,\-]+$', w))
    if len(words) >= 4 and english_words / len(words) > 0.7 and not re.search(r'[\u4e00-\u9fff]', title):
        return True
    return False
```

### 4. 繁体中文未转简体（BBC 中文 RSS）

**修复** (`filter_news.py`) - 使用 OpenCC：
```bash
pip install opencc-python-reimplemented
```
```python
from opencc import OpenCC
cc = OpenCC('t2s')
title = cc.convert(title)
summary = cc.convert(summary)
```

## 运行顺序

```bash
cd /home/kan/signal_pop
python3 src/fetch_news.py      # 抓取 → data/raw_feed.json
python3 src/filter_news.py --mode daily --top 10  # 过滤 → data/filtered_news.json
python3 src/generate_script.py daily              # 生成 → output/daily/
python3 src/tts_mimo.py daily                     # 生成音频
```

## 关键文件位置

- 源码：`/home/kan/signal_pop/src/`
- 数据：`/home/kan/signal_pop/data/`
- 输出：`/home/kan/signal_pop/output/daily/`, `output/weekly/`
- 配置：环境变量 `MINIMAX_API_KEY`, `MINIMAX_BASE_URL`

## 发布规律

- **Daily**：周一、三、五 08:30，10 条新闻（国内 3、科技 3、国际 4），纯新闻无观点
- **Weekly**：周六 09:00，12+ 条热点 + 个人观点段落
- 语音：女声 `xiaoxiao`，男声 `yunyang` (MiMo v2.5 TTS)

## 调试技巧

```bash
# 查看原始抓取
cat data/raw_feed.json | jq '.[] | {title, source, summary: .summary[:80]}'

# 查看过滤后
cat data/filtered_news.json | jq '.[] | {title, category, summary: .summary[:80]}'

# 查看最新脚本
cat output/daily/signal_pop_daily_latest.txt
```