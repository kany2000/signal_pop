---
name: signal-pop-pipeline-fix
description: Signal Pop 新闻播报流水线修复 - 解决 HTML 实体残留、摘要截断、垃圾内容混入、繁体未转简体、英文标题未翻译等问题
category: devops
tags: [signal-pop, news-pipeline, python, rss, filtering]
---

# Signal Pop 流水线修复记录

## 问题背景
每日新闻脚本出现：
- HTML 实体未解码：`作者&nbsp;|&nbsp;王晗玉`
- 摘要硬截断半句：`此次融资将..`、`过...`
- 体育/娱乐/财经行情/博彩广告混入
- BBC 中文繁体未转简体
- 英文标题未翻译直接输出

## 修复方案

### 1. fetch_news.py - 摘要清理与智能截断
```python
import html
import re

# 解码 HTML 实体
summary = html.unescape(summary)

# 智能截断：在句号/问号/感叹号处截断
if len(summary) > 300:
    match = re.search(r'[。！？.!?]', summary[:300])
    if match:
        summary = summary[:match.end()]
    else:
        summary = summary[:300]
```

### 2. filter_news.py - 多层过滤与清理
```python
# 依赖
pip install opencc-python-reimplemented

# 核心功能
- HTML 实体解码: html.unescape()
- 繁体转简体: OpenCC('t2s')
- 垃圾内容关键词过滤 (体育/娱乐/财经行情/博彩/低质)
- 英文标题检测过滤 (正则 + 中文字符占比)
```

### 3. 垃圾关键词清单 (SPAM_KEYWORDS)
- 体育: 世界杯、FIFA、NBA、奥运、裁判、进球、比分...
- 娱乐: 票房、电影、玩具总动员、漫威、奥斯卡...
- 财经行情: 美元指数、期铜、LME、收盘、涨停、北向资金...
- 博彩广告: 点击浏览、即时更新、精彩进球、赔率、盘口...
- 低质: quiz、是什么、你是什么...

### 4. 英文标题检测逻辑
```python
# 全英文
re.match(r'^[A-Za-z\s\.,\-\'\?]+$', title)

# 英文句式开头无中文
re.match(r'^[A-Z][a-z]+\s+[a-z]+', title) and not re.search(r'[\u4e00-\u9fff]', title)

# 英文单词占比 >70% 且无中文
english_words / total_words > 0.7 and no_chinese
```

## 验证结果
修复后输出示例：
```
第1条，国内新闻。金饰克价一夜又跌11元。
据 36kr 报道，6月20日，国内黄金饰品价格对比显示...
第5条，科技新闻。诺贝尔奖得主约翰·江珀宣布加盟Anthropic。
据 36kr 报道，当地时间6月19日...
```

## 人工选题分工 (2026-06-20 约定)
- **新闻选题负责人**：虾小图 (@opclwtg_one_bot)
- **职责**：每期从原始 70 条 `raw_feed.json` 中精选 10 条，剔除重复/标题不对题/低质内容
- **介入点**：`filter_news.py` 运行前，人工生成/修订 `filtered_news.json`
- **后续自动化**：`generate_script.py` → `tts_mimo.py` → 视频合成保持不变

## 工作流模式对比 (2026-06-22 实测)

| 维度 | Monitor 方式 (新) | 脚本方式 (旧) |
|------|-------------------|---------------|
| 触发 | 文件落地即触发 (≤10 min) | 固定时间 cron |
| 人工介入 | 虾小图投放 filtered_news.json | filter_news.py 自动跑 |
| 灵活性 | 高 - 可随时补发/改发 | 低 - 错过时间点需手动跑 |
| 稳定性 | 高 - 内容 hash 去重 | 中 - 依赖时间判断 |
| 当前状态 | **主流程** | 回退/兼容 |

> Monitor 方式已验证端到端通：6月20日周六新闻 → filtered_news.json → monitor_pipeline.py → 脚本+双声道音频+归档，全程自动。

## 文件位置
- `/home/kan/signal_pop/src/fetch_news.py`
- `/home/kan/signal_pop/src/filter_news.py`
- `/home/kan/signal_pop/src/generate_script.py`
- `/home/kan/signal_pop/src/tts_mimo.py`
- `/home/kan/signal_pop/src/tts_google.py`
- `/home/kan/signal_pop/src/monitor_pipeline.py`  # 监控触发器

## 监控流水线自动化 (2026-06-20 新增)

### 触发机制
监控 `/home/kan/shared/signal_pop/filtered_news.json`，检测到新文件即触发完整流水线：
1. 复制到 `/home/kan/signal_pop/data/filtered_news.json`
2. 运行 `generate_script.py daily` → 生成播报脚本
3. 运行 `tts_mimo.py (female)` → 生成女声音频
4. 运行 `tts_mimo.py (male)` → 生成男声音频 (备用)
5. 输出文件到 `/home/kan/signal_pop/output/daily/`
6. 处理完成后，将源文件重命名为 `filtered_news_YYYYMMDD_HHMMSS.json` 归档

### 去重策略
- 使用 **内容 SHA-256 hash** 作为主键去重（而非 mtime）
- 状态持久化到 `/home/kan/signal_pop/.pipeline_state.json`
- 重启后仍能识别已处理文件

### 定时任务建议
```bash
# 每 10 分钟检查一次 (monitor 方式 - 推荐)
*/10 * * * * cd /home/kan/signal_pop && python src/monitor_pipeline.py >> /home/kan/signal_pop/logs/monitor.log 2>&1
```

### 已部署的 Cron 任务 (2026-06-22)
| 任务名 | Job ID | 计划 | 方式 |
|--------|--------|------|------|
| signal-pop-monitor | 9967e8b8c86f | `*/10 * * * *` | Monitor: 监控 shared 目录 filtered_news.json |
| signal-pop-weekly | 7968abe94f69 | `0 9 * * 6` (周六 09:00) | Weekly: 生成带观点的周报 |

**预存 Cron 任务 (脚本方式，保留兼容)**
| 任务名 | 计划 | 方式 |
|--------|------|------|
| signal-pop-daily-news | `30 8 * * 1,3,5` (周一三五 08:30) | 脚本: `scripts/generate_audio_one.sh` |
| signal-pop-weekly-news | `0 9 * * 6` (周六 09:00) | 脚本: `scripts/generate_audio_one.sh weekly` |
| signal-pop-daily-check | `0 9 * * 1,3,5` (周一三五 09:00) | 健康检查 daily-news |

> **优先级**: Monitor 方式 (human-in-the-loop) 为主流程，脚本方式保留作为回退。虾小图在 shared 目录投放 `filtered_news.json` 即触发 monitor 流水线。

### 关键修复记录
- **Bug**: 归档移动文件后尝试 stat 原路径导致 FileNotFoundError
- **Fix**: 先获取 stat 和 hash，再执行移动操作
- **优化**: 去重从 `mtime + hash` 简化为仅 `hash`，避免同一文件不同时间戳被重复处理

### 5. TTS 文本规范化 (2026-06-22 新增)

**问题**: TTS 朗读时 `（-11元）`、`(-9元)` 等括号内负数会被逐字读出（"左括号 负 11 元 右括号"），影响收听体验。

**修复** (`generate_script.py` 新增 `normalize_for_tts()` 函数，在输出前统一处理)：
```python
def normalize_for_tts(text: str) -> str:
    # 1. （-11元）→ 跌11元 （全角括号）
    text = re.sub(r'（-\s*(\d+(?:\.\d+)?)\s*元）', r'跌\1元', text)
    # 2. (-11元) → 跌11元 （半角括号）
    text = re.sub(r'\(-\s*(\d+(?:\.\d+)?)\s*元\)', r'跌\1元', text)
    # 3. （-9元）→ 跌9元 等类似模式（全角/半角）
    text = re.sub(r'（-\s*(\d+(?:\.\d+)?)\s*([元美元%])\）', r'跌\1\2', text)
    text = re.sub(r'\(-\s*(\d+(?:\.\d+)?)\s*([元美元%])\\)', r'跌\1\2', text)
    # 4. （-数字）通用 → 下跌数字
    text = re.sub(r'（-\s*(\d+(?:\.\d+)?)\）', r'下跌\1', text)
    text = re.sub(r'\(-\s*(\d+(?:\.\d+)?)\)', r'下跌\1', text)
    # 5. （+数字）通用 → 上涨数字
    text = re.sub(r'（\+\s*(\d+(?:\.\d+)?)\）', r'上涨\1', text)
    text = re.sub(r'\(\+\s*(\d+(?:\.\d+)?)\)', r'上涨\1', text)
    # 6. 清理重复标点/多余空格
    text = re.sub(r'[。，]{2,}', '。', text)
    text = re.sub(r'\s{2,}', ' ', text)
    return text
```

**处理对照**:
| 原文 | 规范化后 | 说明 |
|------|----------|------|
| `老庙黄金1268元/克（-11元）` | `老庙黄金1268元/克跌11元` | 全角括号 |
| `周生生1263元/克(-9元)` | `周生生1263元/克跌9元` | 半角括号 |
| `（+5%）` | `上涨5%` | 正向变动 |
| `（-100）` | `下跌100` | 无单位通用 |

**验证**: 6月20日新闻重新生成音频，女声/男声均正确朗读 "跌11元"、"跌9元"。