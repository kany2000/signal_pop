---
name: lan-share-server
description: Set up a LAN HTTP file share for multi-agent collaboration — Python server, persistence, directory organization.
platforms: [linux]
---

# LAN Share Server

Multi-agent file sharing over HTTP on a local network. Lightweight, zero dependencies beyond Python 3.

## Setup

### Server Script

Use `/home/kan/scripts/share-server.py` as the base:

```python
# Key features:
# - GET /path → browse/download files (with styled HTML directory listing)
# - GET /api/list → JSON file list (machine-readable)
# - PUT /path → upload file (curl -X PUT ... --data-binary @file)
# - POST / → browser form upload (multipart)
# - 0.0.0.0:PORT, default 8080
# - Optional HTTP Basic Auth via SHARE_AUTH=user:pass
```

### Persistence

When systemd not available (no sudo), use crontab @reboot:

```bash
(crontab -l 2>/dev/null || true; echo "@reboot cd /home/kan/shared && python3 /home/kan/scripts/share-server.py > /tmp/share-server.log 2>&1 &") | crontab -
```

Verify: `crontab -l | grep share`

If systemd available:
```bash
sudo cp share-server.service /etc/systemd/system/
sudo systemctl enable share-server
sudo systemctl start share-server
```

## Directory Organization

**Critical rule — ONLY the user creates top-level directories.** Each bot/agent gets their own directory assigned by the user. Never create directories for other agents, never move/rename them.

```
/home/kan/shared/
  ├── bot-a/             # ← user assigns, agent fills
  │   ├── project-x/
  │   └── script-y.py
  ├── bot-b/             # ← user assigns
  └── bot-c/             # ← user assigns
```

**Golden rules:**
1. Only work inside your own assigned directory
2. Never `mv` / `rm` / rename another agent's directory
3. Never create new top-level directories yourself — ask the user
4. File conflicts from PUT are real — only PUT into your own dir

### Sharing Local Files Without Breaking Cron Jobs

Never move/delete local source files — cron jobs depend on local paths.

**Option A — Copy (safe for small projects):**
```bash
# ✅ Copy to share, local untouched
cp -r /local/small-project/ /home/kan/shared/mydir/
```

**Option B — Soft-link (cheap, stays synced):**
```bash
# ✅ Symlink — no disk copy, auto-updates with local changes
ln -s /local/large-project /home/kan/shared/mydir/large-project
```

**❌ Wrong — breaks cron:**
```bash
mv /local/project/ /home/kan/shared/mydir/   # NO — cron references old path
```

### Pre-reorg Audit

Before reorganizing any files that might affect cron jobs:
```bash
hermes cron list            # List all cron jobs
grep -r "/home/kan/" .      # Check for local path references
# Then verify: does any cron job reference a path I'm about to touch?
```

## Agent Usage

```bash
# Download
curl -O http://10.10.10.30:8080/path/file
wget http://10.10.10.30:8080/path/file

# Upload
curl -X PUT http://10.10.10.30:8080/mydir/file.txt --data-binary @local.txt

# List files (JSON)
curl http://10.10.10.30:8080/api/list

# Browse (HTML UI with upload button)
# http://10.10.10.30:8080/
```

## Cron Job Safety

Before reorganizing files, audit cron jobs:

```bash
hermes cron list   # See all cron jobs with file paths
```

If a cron job references a local path (e.g., `/home/kan/signal_pop/scripts/`):
1. Keep the original files in place
2. Copy to shared folder as secondary access
3. Never use `mv` on project directories that cron jobs depend on

## Pitfalls

- **Files disappearing between commands**: Multiple agents may modify the shared directory simultaneously. Always check before assuming state.
- **No sudo for systemd**: Use crontab @reboot as fallback.
- **Port conflicts**: Check with `ss -tlnp | grep 8080`.
- **Firewall**: Some LANs block non-standard ports; verify with a curl from another machine.
- **File conflicts**: Agents overwriting each other's files is a real risk with PUT. Educate contributors to only touch their own directory.
