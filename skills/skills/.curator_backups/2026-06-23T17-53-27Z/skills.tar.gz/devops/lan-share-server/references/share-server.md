# Share Server Script

The server at `/home/kan/scripts/share-server.py` is a standalone Python HTTP server.

## Invocation

```bash
# Default (port 8080, dir /home/kan/shared)
python3 /home/kan/scripts/share-server.py

# Custom config via env vars
SHARE_DIR=/custom/path SHARE_PORT=9090 python3 /home/kan/scripts/share-server.py
```

## API Reference

| Method | Path | Description |
|--------|------|-------------|
| GET | `/` | HTML directory listing + upload form |
| GET | `/path/to/file` | Download file |
| GET | `/api/list` | JSON array of all files (name, size, modified) |
| PUT | `/path/to/file` | Upload file (binary via request body) |
| POST | `/` | Upload via browser multipart form |

## Dependencies
- Python 3.7+ (stdlib only: http.server, json, os, html, cgi, urllib)
- No pip packages required

## Security
- No auth by default (set `SHARE_AUTH=user:pass` to enable Basic auth)
- Path traversal protection built in
- CORS headers for cross-origin access
