# World Cup 2026 Daily Collection Pipeline

**Operational record** of the RSS-based intelligence collection system built for the June 2026 prediction.

---

## Collection Script

**Location**: `~/worldcup-analysis/scripts/collect_daily.py`

### Architecture

```
RSS Feeds (3) ──→ Fetch & Parse ──→ Keyword Filter ──→ Classify ──→ Save
  BBC Sport                           95+ WC keywords    INJURY      report.txt
  The Guardian                        48 team names      SQUAD       raw.json
  Sky Sports                          6 article types    COACHING
                                                          ODDS
                                                          MATCH
                                                          GENERAL
```

### Keyword Filtering

~95 keywords covering:
- Tournament names: "world cup", "world cup 2026", "wc2026", "fifa world cup"
- All 12 group teams by name (France, Brazil, Argentina, England, etc.)
- Star players: Mbappé/Mbappe, Messi, Vinicius, Bellingham, Kane, etc.
- News categories: "injury", "squad", "roster", "call-up", "friendly"
- Roles: "coach", "manager", Tuchel, Deschamps, Scaloni

### Classification Logic

| Type | Trigger Keywords |
|------|-----------------|
| INJURY | injury, injured, sidelined, surgery, fracture, hamstring |
| SQUAD | squad, call-up, roster, named, selection |
| COACHING | manager, coach, sacked, appointed, resign |
| ODDS | odds, betting, favourite, favorite, prediction |
| FRIENDLY | friendly, warm-up, pre-season, training |
| MATCH | goal, win, defeat, draw, score, match, result |
| GENERAL | (catch-all) |

### Signal Summary (daily output)

At end of each run, the script generates:
- **Hot teams graph**: bar chart of which teams had most mentions today (e.g. `England: ██████████ (21条)`)
- **Key signals**: top injuries flagged with ⚠️, coaching changes flagged with 🔄
- **Article counts**: total fetched vs WC-related, breakdown by type

---

## Cron Jobs

### Daily Data Collection (Jun 3-7+) — Multi-Script

```
job_id: 2334a48c48d3
name: worldcup-daily-collect
schedule: "0 12 * * *" (daily at noon)
repeat: 5 times (Jun 3 → Jun 7+)
deliver: local (saves files, no chat spam)
prompt: Runs collect_daily.py + scrape_all.py
```

**Now runs TWO scripts each tick:**
1. `python3 collect_daily.py` — RSS news (BBC/Guardian/Sky Sports)
2. `python3 scrape_all.py` — BOTH Free API Live Football Data + The Odds API (multisource odds)

Note: `scrape_all.py` replaced the old `scrape_odds.py` on Jun 4. The new script:
- Uses `.odds_config.json` for API key storage (see `scripts/scrape_all.py --save-odds-api KEY` to register)
- Fetches outright winner odds from The Odds API (4 regions: EU/UK/US/AU)
- Fetches WC match odds from The Odds API (72 events)
- Falls back to Free API Live Football Data for qualifier match odds if available
- Computes 4-region consensus and outputs `odds_latest.json` with computed `consensus` field (team → avg_odds/best_odds/implied_prob)
- **Handles intermittent "INVALID_KEY" errors** from The Odds API with retry loop (5 attempts, 3-5s delay)

Why `deliver: local` — daily collection is internal; only the final analysis needs to reach the user.

### Final Analysis (Jun 8)

```
job_id: d019e138b604
name: worldcup-final-analysis-june8
schedule: "2026-06-08T09:00:00" (one-shot ISO timestamp)
repeat: once
deliver: origin (posts to the Telegram group chat)
prompt: Reads all daily reports + odds data + comprehensive analysis → outputs final prediction
```

---

## What Worked / What Didn't

### ✅ Worked (Jun 4 update)
- **BBC Sport RSS**: 82 items per fetch, excellent World Cup coverage
- **The Guardian RSS**: 60 items, strong international football coverage
- **Sky Sports RSS**: 20 items, UK-focused but useful
- **HTTPS/requests**: environment has unrestricted outbound HTTPS
- **Python RSS parsing**: `xml.etree.ElementTree` handles both RSS 2.0 and Atom formats
- **Daily file output**: `daily_collection/report_YYYY-MM-DD.txt` + `raw_YYYY-MM-DD.json`
- **The Odds API (new key, with retry logic)**: Successfully fetches outright winner odds from 4 regions (54+ teams) and 72 WC match events. Key is `5c1f51f1556cd6e6af9387a637cb1113` (free tier, 500 credits).

### ⚠️ Worked with Caveats
- **The Odds API intermittent key failures**: The API returns `"INVALID_KEY"` intermittently (not rate limiting — CloudFront cache behavior). **Mitigation**: retry loop with 3-5 second delays. Works on 3rd-5th attempt consistently.
- **Free API Live Football Data**: 204 WC qualifier matches found, but per-match odds detail calls get rate-limited (HTTP 429). Only ~4 match odds retrievable per session.

### ❌ Didn't Work
- **Browser-based odds scraping**: browser daemon failed to start, alternatives (Oddschecker, BetExplorer) blocked or JS-rendered
- **Wikipedia API**: printable version returned ToC only, not actual content
- **Web scraping sportsbooks**: most block automated requests (403/404)

### Mitigation (Jun 4 update)

The Odds API key was replaced with a fresh account (`5c1f51f1...`, 500 credits). The new `scrape_all.py` script adds:
- Retry logic for The Odds API's intermittent "INVALID_KEY" responses
- Config file pattern for API keys (`.odds_config.json`, `chmod 600`)
- Multi-region consensus (4 regions → stable implied probabilities)
- Combined prediction model: 40% baseline analysis + 30% odds consensus + 30% RSS news signal

For future tournaments, pre-register for The Odds API free tier (~500 requests/month) and store the key in `.odds_config.json` before starting.

---

## Directory Structure (as of Jun 4, 2026)

```
~/worldcup-analysis/
├── .odds_config.json            # API keys (chmod 600, encrypted not)
├── daily_collection/
│   ├── report_2026-06-02.txt
│   ├── report_2026-06-03.txt
│   ├── report_2026-06-04.txt
│   ├── report_2026-06-05.txt
│   ├── report_2026-06-06.txt
│   ├── report_2026-06-07.txt
│   ├── raw_2026-06-02.json
│   ├── raw_2026-06-03.json
│   └── ...
├── scripts/
│   ├── collect_daily.py         # RSS news collection
│   ├── scrape_all.py            # Multi-source odds (Odds API + Free API)
│   └── final_predict.py         # Weighted prediction (40% analysis + 30% odds + 30% news)
├── odds_data/
│   ├── odds_latest.json         # Latest odds with computed consensus
│   ├── scrape_20260604_*.json   # Historical odds snapshots
│   └── theoddsapi_20260604_*.json
├── reports/
│   └── FINAL_COMPREHENSIVE_ANALYSIS.md
└── data/
    ├── 01_historc_data.md
    └── 03_team_analysis.md
```
