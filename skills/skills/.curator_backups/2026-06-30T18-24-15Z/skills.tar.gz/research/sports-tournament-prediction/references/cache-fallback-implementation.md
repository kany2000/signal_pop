# Cache Fallback Implementation (World Cup 2026)

## Context

The Odds API free tier (500 req/mo) exhausted during daily collection for World Cup 2026 prediction pipeline. This doc records the exact implementation pattern used to gracefully degrade.

## Pattern: Fetch-or-Cache

```python
# In scrape_odds.py / collect script:

CACHE_PATH = "odds_data/odds_latest.json"

def collect_odds_api():
    """Return (data_dict, source_label). Never crash."""
    data = try_fetch_odds_api()
    if data and len(data) > 0:
        # API returned data → save cache + return fresh
        save_odds_cache(data, CACHE_PATH)
        return data, "live"
    
    # API empty/failed → load cache
    cached = load_odds_cache(CACHE_PATH)
    if cached:
        cached_at = cached.get("_cached_at", "unknown")
        return cached, f"cached from {cached_at}"
    
    return {}, "no data (all sources exhausted)"
```

## Key Design Decisions

1. **`source_label` field everywhere**: Propagate a string tag through the entire pipeline — analysis script, prediction script, output formatter. Each component reads it and displays it.
2. **Fresh data saves cache**: When API succeeds, overwrite cache file AND return `"live"`. This means the cache always contains the most recent successful fetch.
3. **`_cached_at` metadata**: When saving cache, inject a `"_cached_at"` field with ISO date so downstream knows staleness.
4. **Never crash**: Even if both API and cache fail, return empty dict — the caller handles missing data gracefully.

## Example Output Annotation

```
赔率来源: 缓存赔率 (最后更新: 2026-06-05)
⚠️ 注意：原始赔率数据最后更新于 2026-06-05，距开赛6天，赔率变化极小。
```

## File Structure

```
scripts/
├── scrape_all.py          # Main: try API → save cache → return
├── final_predict.py       # Consumer: reads source field from odds data
└── odds_data/
    ├── odds_latest.json   # Auto-updated cache with _cached_at field
    └── (backups)          # Previous dumps preserved
```

## Related

- SKILL.md: "Graceful Degradation (Pipeline Must Not Crash)" principle
- SKILL.md: "Cache fallback" step in Fallback Strategy
