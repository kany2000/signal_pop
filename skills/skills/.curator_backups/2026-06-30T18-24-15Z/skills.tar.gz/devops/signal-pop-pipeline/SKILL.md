---
name: signal-pop-pipeline
description: Signal Pop (隔天信号弹) 新闻管道维护技能。覆盖 RSS 抓取 → 过滤 → 脚本生成 → TTS → 发布的全流程常见问题修复与最佳实践。
tags:
  - signal-pop
  - news-pipeline
  - rss
  - content-filtering
  - chinese-nlp
category: devops
---

# Signal Pop 新闻管道维护

## 管道架构

```
fetch_news.py → filter_news.py → generate_script.py → tts_mimo.py → 发布
     ↓              ↓                ↓               ↓
  RSS源抓取      去重/分类/清洗    播报文本生成      MiMo TTS音频
```

## 常见问题与修复

### 1. HTML 实体未解码 (`&nbsp;`, `&amp;`, `&lt;` 等)

**症状**：生成脚本中出现 `作者&nbsp;|&nbsp;王晗玉`

**修复** (`fetch_news.py`)：
```python
import html
summary = html.unescape(summary)  # 在 re.sub 之后调用
```

### 2. 摘要硬截断导致半句残缺

**症状**：`"此次融资将.."`、`"过..."`

**修复** (`fetch_news.py`) - 智能截断在句号处：
```python
if len(summary) > 300:
    match = re.search(r'[。！？.!?]', summary[:300])
    if match:
        summary = summary[:match.end()]
    else:
        summary = summary[:300]
```

### 3. 垃圾内容混入（体育/娱乐/财经行情/博彩/英文标题）

**症状**：FIFA 世界杯、电影票房、美元指数/期铜价格、博彩广告、未翻译英文标题

**修复** (`filter_news.py`) - 多层过滤：

```python
SPAM_KEYWORDS = [
    # 体育赛事
    "世界杯", "FIFA", "欧冠", "英超", "NBA", "裁判", "进球", "比分", "赛程",
    # 娱乐八卦
    "票房", "电影", "上映", "玩具总动员", "漫威", "迪士尼",
    # 财经行情（非新闻类）
    "美元指数", "期铜", "收盘", "涨停", "北向资金", "LME", "WTI",
    # 博彩/广告
    "点击浏览", "即时更新", "精彩进球", "万勿错过", "竞猜", "赔率",
]

def is_spam(title, summary):
    text = (title + " " + summary).lower()
    for kw in SPAM_KEYWORDS:
        if kw.lower() in text:
            return True
    # 检测全英文/高英文比例标题
    if re.match(r'^[A-Za-z\s\.,\-\'\?]+$', title.strip()) and len(title) > 5:
        return True
    words = title.split()
    english_words = sum(1 for w in words if re.match(r'^[A-Za-z\.\,\-]+$', w))
    if len(words) >= 4 and english_words / len(words) > 0.7 and not re.search(r'[\u4e00-\u9fff]', title):
        return True
    return False
```

### 4. 繁体中文未转简体（BBC 中文 RSS）

**修复** (`filter_news.py`) - 使用 OpenCC：
```bash
pip install opencc-python-reimplemented
```
```python
from opencc import OpenCC
cc = OpenCC('t2s')
title = cc.convert(title)
summary = cc.convert(summary)
```

## 运行顺序

```bash
cd /home/kan/signal_pop
python3 src/fetch_news.py      # 抓取 → data/raw_feed.json
python3 src/filter_news.py --mode daily --top 10  # 过滤 → data/filtered_news.json
python3 src/generate_script.py daily              # 生成 → output/daily/
python3 src/tts_mimo.py daily                     # 生成音频
```

## 关键文件位置

- 源码：`/home/kan/signal_pop/src/`
- 数据：`/home/kan/signal_pop/data/`
- 输出：`/home/kan/signal_pop/output/daily/`, `output/weekly/`
- 配置：环境变量 `MINIMAX_API_KEY`, `MINIMAX_BASE_URL`

## 多平台自动分发组件

- **部署位置**：`/home/kan/shared/social-auto-upload/`
- **核心脚本**：`scripts/auto_publish.py` (见本 skill `scripts/` 目录) — 扫描 `/home/kan/shared/her2home/`，读取同名 `.json` 元数据，并行分发到 4 平台，去重记录 `.publish_state.json`
- **登录脚本**：`login_all_platforms.sh` — 一键登录 4 平台 (首次扫码，cookie 持久化)
- **Cron 任务**：每天 10:30、16:30 运行 (对齐马小v ~10:00 出片节奏)

## 多平台自动分发 (social-auto-upload)

### 架构
```
马小v出片 → /home/kan/shared/her2home/video_xxx.mp4 + .png + .json
                ↓
         cron (10:30/16:30) 扫描
                ↓
         auto_publish.py 并行分发
                ↓
    ┌─────┬─────┬─────────┬────────┐
    ↓     ↓     ↓         ↓
  抖音   B站   小红书     快手
  定时发布
```

### 部署路径
- 仓库：`/home/kan/shared/social-auto-upload/` (13k⭐ dreammis/social-auto-upload)
- CLI：`sau douyin|bilibili|xiaohongshu|kuaishou ...`
- 登录脚本：`/home/kan/shared/social-auto-upload/login_all_platforms.sh` (首次扫码，cookie 持久化)
- 分发脚本：`/home/kan/shared/social-auto-upload/auto_publish.py`

### 分发脚本逻辑 (auto_publish.py)
1. 扫描 `/home/kan/shared/her2home/*.mp4`
2. 匹配同名 `.png/.jpg` (封面) + `.json` (元数据)
3. 读取 `.publish_state.json` 去重 — **同一文件名绝不重复上传**
4. 并行 `sau` 上传 4 平台 (含 `--schedule "次日 08:30"`)
5. 成功写入状态文件，失败下轮重试

### 元数据 JSON 模板
```json
{
  "title": "隔天信号弹 6.28｜标题",
  "desc": "简介内容...",
  "tags": "隔天信号弹,AI,科技",
  "schedule": "2026-06-29 08:30"   // 选填，默认次日 08:30
}
```

#### Cron 调度时间 (对齐团队节奏)

- 虾小图产出新闻稿：08:00-08:30
- 马小v 生成视频：~10:00
- 自动分发检查：**10:30 和 16:30** 两次/天 (足够覆盖，无需 30 分钟频率)
- 周刊：周六 09:00 发布

---

### OpenMontage 评估参考 (2026-06-26)

OpenMontage (calesthio/OpenMontage, 22k⭐, AGPL-3.0) 是开源 agentic 视频制作系统，与 Signal Pop 高度相关：

- **核心管道**: `documentary-montage` (新闻蒙太奇)、`hybrid` (混合素材+生成，对标 HyperFrames)、`clip-factory` (长切短)、`talking-head` (口播)
- **工具覆盖**: 免费素材直连 (Pexels/Pixabay/Archive.org)、CLIP 语义检索、多渲染引擎 (HyperFrames/Remotion/FFmpeg)、专业级动态字幕、TTS 多提供商
- **架构对齐**: Executive Producer 编排 + checkpoint 审批 + 质量门控 + 预算控制 + 技能复用
- **已 clone 到**: `/home/kan/shared/OpenMontage/` 供团队现学现用
# 查看过滤后
cat data/filtered_news.json | jq '.[] | {title, category, summary: .summary[:80]}'

# 查看最新脚本
cat output/daily/signal_pop_daily_latest.txt
```