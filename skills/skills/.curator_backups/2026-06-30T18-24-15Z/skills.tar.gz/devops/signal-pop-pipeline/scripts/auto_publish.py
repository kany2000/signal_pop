#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Signal Pop 自动分发脚本
- 监控 /home/kan/shared/her2home/ 新视频+封面
- 读取同名 .json 元数据（标题、简介、标签、定时时间）
- 并行分发到抖音、B站、小红书、快手
- 发布成功后记录日志，避免重复发布
"""

import json
import os
import subprocess
import sys
import time
from datetime import datetime
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed

# 配置
WATCH_DIR = Path("/home/kan/shared/her2home")
STATE_FILE = WATCH_DIR / ".publish_state.json"
ACCOUNT = "her2home"
PLATFORMS = ["douyin", "bilibili", "xiaohongshu", "kuaishou"]

# 抖音竖版封面 3:4, B站横版 16:9
THUMBNAIL_ARGS = {
    "douyin": ["--thumbnail-portrait"],
    "bilibili": ["--thumbnail-landscape"],
    "xiaohongshu": ["--thumbnail"],
    "kuaishou": ["--thumbnail"],
}

# B站分区 tid: 249 = 科技/数码
BILIBILI_TID = 249

def load_state():
    if STATE_FILE.exists():
        with open(STATE_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    return {"published": {}}

def save_state(state):
    with open(STATE_FILE, "w", encoding="utf-8") as f:
        json.dump(state, f, ensure_ascii=False, indent=2)

def find_new_videos(state):
    """扫描目录，返回未发布的视频文件列表"""
    published = state.get("published", {})
    new_videos = []
    for video_file in WATCH_DIR.glob("*.mp4"):
        if video_file.name in published:
            continue
        # 检查是否有同名封面
        cover_file = video_file.with_suffix(".png")
        if not cover_file.exists():
            cover_file = video_file.with_suffix(".jpg")
        if not cover_file.exists():
            print(f"⚠️ 缺少封面: {video_file.name}")
            continue
        # 检查元数据文件
        meta_file = video_file.with_suffix(".json")
        meta = {}
        if meta_file.exists():
            with open(meta_file, "r", encoding="utf-8") as f:
                meta = json.load(f)
        new_videos.append({
            "video": video_file,
            "cover": cover_file,
            "meta": meta,
        })
    return new_videos

def build_upload_cmd(platform, video_path, cover_path, meta):
    """构建 sau 上传命令"""
    title = meta.get("title", f"隔天信号弹 {datetime.now().strftime('%m.%d')}")
    desc = meta.get("desc", "每日硬核资讯，十条直达核心。")
    tags = meta.get("tags", "隔天信号弹,科技资讯,AI,新闻")
    schedule = meta.get("schedule")  # 格式: "2026-06-28 08:30"

    cmd = [
        "sau", platform, "upload-video",
        "--account", ACCOUNT,
        "--file", str(video_path),
        "--title", title,
        "--desc", desc,
        "--tags", tags,
    ]

    # 平台特定参数
    if platform == "bilibili":
        cmd.extend(["--tid", str(BILIBILI_TID)])
    if platform in THUMBNAIL_ARGS:
        cmd.extend(THUMBNAIL_ARGS[platform])
        cmd.append(str(cover_path))

    # 定时发布
    if schedule:
        cmd.extend(["--schedule", schedule])
    else:
        # 默认立即发布（或按需求设为次日早 8:30）
        tomorrow = datetime.now().replace(hour=8, minute=30, second=0, microsecond=0)
        if tomorrow <= datetime.now():
            from datetime import timedelta
            tomorrow += timedelta(days=1)
        cmd.extend(["--schedule", tomorrow.strftime("%Y-%m-%d %H:%M")])

    return cmd

def upload_one(platform, video_path, cover_path, meta):
    """上传单个平台"""
    cmd = build_upload_cmd(platform, video_path, cover_path, meta)
    print(f"🚀 [{platform}] 上传: {video_path.name}")
    print(f"   命令: {' '.join(cmd)}")
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=600)
        if result.returncode == 0:
            print(f"✅ [{platform}] 成功")
            return True, result.stdout
        else:
            print(f"❌ [{platform}] 失败: {result.stderr}")
            return False, result.stderr
    except subprocess.TimeoutExpired:
        print(f"⏱️ [{platform}] 超时")
        return False, "timeout"
    except Exception as e:
        print(f"💥 [{platform}] 异常: {e}")
        return False, str(e)

def publish_video(video_info):
    """并行发布到所有平台"""
    video_path = video_info["video"]
    cover_path = video_info["cover"]
    meta = video_info["meta"]

    print(f"\n{'='*60}")
    print(f"📤 处理视频: {video_path.name}")
    print(f"📋 元数据: {json.dumps(meta, ensure_ascii=False)}")
    print(f"{'='*60}")

    results = {}
    with ThreadPoolExecutor(max_workers=4) as executor:
        futures = {
            executor.submit(upload_one, p, video_path, cover_path, meta): p
            for p in PLATFORMS
        }
        for future in as_completed(futures):
            platform = futures[future]
            success, output = future.result()
            results[platform] = {"success": success, "output": output}

    # 汇总
    all_ok = all(r["success"] for r in results.values())
    status = "✅ 全部成功" if all_ok else "⚠️ 部分失败"
    print(f"\n📊 发布结果: {status}")
    for p, r in results.items():
        mark = "✅" if r["success"] else "❌"
        print(f"   {mark} {p}")

    return video_path.name, all_ok, results

def main():
    print(f"🕐 {datetime.now().strftime('%Y-%m-%d %H:%M:%S')} 开始扫描...")

    state = load_state()
    new_videos = find_new_videos(state)

    if not new_videos:
        print("📭 无新视频待发布")
        return

    print(f"📥 发现 {len(new_videos)} 个新视频")

    for video_info in new_videos:
        video_name, all_ok, results = publish_video(video_info)
        if all_ok:
            state["published"][video_name] = {
                "time": datetime.now().isoformat(),
                "platforms": {p: r["success"] for p, r in results.items()},
            }
            save_state(state)
        else:
            print(f"⚠️ {video_name} 发布不完全，下次重试")

    print(f"\n🏁 完成")

if __name__ == "__main__":
    main()