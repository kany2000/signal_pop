# 多平台视频自动分发 - 登录与运维参考

## 登录流程标准化

### 一键登录脚本
```bash
# 位置: /home/kan/shared/social-auto-upload/login_all_platforms.sh
#!/usr/bin/env bash
set -euo pipefail

ACCOUNT="her2home"
PLATFORMS=("douyin" "bilibili" "xiaohongshu" "kuaishou")

for p in "${PLATFORMS[@]}"; do
    echo "=== 登录 $p ==="
    sau "$p" login --account "$ACCOUNT" || echo "$p 登录失败，继续下一个"
done

echo "=== 验证所有平台 ==="
for p in "${PLATFORMS[@]}"; do
    sau "$p" check --account "$ACCOUNT" && echo "$p: OK" || echo "$p: INVALID"
done
```

### 单平台登录验证
```bash
sau douyin check --account her2home
sau bilibili check --account her2home
sau xiaohongshu check --account her2home
sau kuaishou check --account her2home
```

## Cookie 管理
- 存储目录：`/home/kan/shared/social-auto-upload/cookies/`
- 文件命名：`<platform>_<account>.json`（如 `douyin_her2home.json`）
- 二维码临时文件：`douyin_<account>_login_qrcode_<timestamp>.png`
- **抖音二维码必须通过 HTTP 链接在手机浏览器打开扫码**，终端 ASCII 码不可靠

## 定时分发架构

### 两层 Cron 任务（每天 10:30、16:30 触发）
| Job ID | 名称 | 作用 |
|--------|------|------|
| `cbef28c8adaa` | 监控马小v视频输出 | 扫描 `/home/kan/shared/her2home/` 新视频+封面+JSON，并行上传 4 平台 |
| `48d0d0f155f1` | Signal Pop 自动分发 | 同目录扫描，分发到 4 平台，定时发布次日 08:30 |

### 状态去重
- 状态文件：`/home/kan/shared/her2home/.publish_state.json`
- Key：文件名（stem），Value：上传时间戳 + 平台结果
- 同名文件不重复上传

### 视频元数据 JSON 模板
```json
{
  "title": "隔天信号弹 2026-06-28：AI突破+热点追踪",
  "description": "本期内容... #隔天信号弹 #AI资讯 #科技新闻",
  "tags": ["隔天信号弹", "AI资讯", "科技新闻", "热点追踪"],
  "schedule": "2026-06-29 08:30",
  "thumbnail": "video_20260628.png"
}
```
- 字段：`title`、`description`、`tags`、`schedule`（可选，格式 `YYYY-MM-DD HH:MM`）、`thumbnail`（可选，默认同名 png）
- B站分区固定：`--tid 249` (科技/数码)

## 平台发布参数差异

| 平台 | CLI 命令 | 封面参数 | 定时参数 | 备注 |
|------|----------|----------|----------|------|
| 抖音 | `sau douyin upload` | `--thumbnail-portrait` | `--schedule "YYYY-MM-DD HH:MM"` | 竖版 3:4 |
| B站 | `sau bilibili upload` | `--thumbnail-landscape` | `--schedule "YYYY-MM-DD HH:MM"` | `--tid 249` 横版 16:9 |
| 小红书 | `sau xiaohongshu upload` | `--thumbnail` | `--schedule "YYYY-MM-DD HH:MM"` | 1:1 或 3:4 |
| 快手 | `sau kuaishou upload` | `--thumbnail` | `--schedule "YYYY-MM-DD HH:MM"` | 横版 16:9 |

## 常见故障排查

### 抖音二维码过期/登录失败
1. 确认已应用补丁（见 `references/douyin-qrcode-login-fix.md`）
2. 运行登录，**马上**打开最新 PNG HTTP 链接扫码
3. 等待「登录成功」日志，验证 `sau douyin check --account her2home` 返回 `valid`

### Cookie 失效
```bash
# 单平台重新登录
sau douyin login --account her2home

# 全平台重新登录
./login_all_platforms.sh
```

### 上传后未定时发布
- 检查 `schedule` 字段格式：`YYYY-MM-DD HH:MM`（24 小时制）
- 服务器时区必须为 `Asia/Shanghai`
- 平台审核可能延迟发布，日志查看：`sau <platform> list --account her2home`

## 目录结构
```
/home/kan/shared/
├── social-auto-upload/          # 克隆的 social-auto-upload 仓库（已打补丁）
│   ├── cookies/                 # 登录凭证 + 二维码图片
│   ├── uploader/douyin_uploader/main.py  # 已修复 Bug
│   ├── login_all_platforms.sh   # 一键登录脚本
│   ├── auto_publish.py          # 自动分发核心脚本
│   └── sau_wrapper.sh           # CLI 入口包装（PYTHONPATH 修正）
├── her2home/                    # 马小v 投递目录
│   ├── video_YYYYMMDD.mp4
│   ├── video_YYYYMMDD.png
│   ├── video_YYYYMMDD.json
│   └── .publish_state.json      # 去重状态
└── signal-pop-hyperframes/      # Signal Pop 视频生成管线（另一套系统）
```

## 关键路径
- `sau` CLI：`/home/kan/shared/social-auto-upload/venv/bin/sau` (symlink → `sau_wrapper.sh`)
- Python 环境：`/home/kan/shared/social-auto-upload/venv/bin/python`
- Patchright Chromium：已安装在 venv 内