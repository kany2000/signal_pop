---
name: multi-platform-video-publishing
description: 多平台视频自动发布自动化技能。覆盖抖音、B站、小红书、快手、视频号、百家号、TikTok、YouTube 等主流平台的视频上传、定时发布、多账号管理、无头模式运行。基于 social-auto-upload (13k⭐) 项目构建。
category: devops
tags:
  - social-media
  - video-publishing
  - automation
  - douyin
  - bilibili
  - xiaohongshu
  - kuaishou
  - tiktok
  - youtube
---

# 多平台视频自动发布自动化

## 适用场景
- 内容创作者/运营需要将同一视频一键分发到多个平台
- 服务器无人值守定时发布
- AI Agent 驱动的自动化内容分发管线
- 多账号矩阵管理

## 核心工具：social-auto-upload
- **GitHub**: https://github.com/dreammis/social-auto-upload (13k⭐)
- **CLI 入口**: `python - **`python -m sau_cli douyin|bilibili|xiaohongshu|kuaishou|tencent|youtube ...`**（项目自带 CLI 模块，非 PyPI `sau` 包）
- **支持平台**: 抖音、B站、小红书、快手、视频号、百家号、TikTok、YouTube
- **核心能力**: 视频上传、封面图、定时发布、多账号、无头模式、AI Agent Skill 化

## 部署标准流程

### 1. 环境准备（Linux / 服务器）
```bash
# 克隆项目到共享文件夹
cd /home/kan/shared
git clone https://github.com/dreammis/social-auto-upload
cd social-auto-upload

# 安装 Python 依赖（可编辑模式）
uv pip install -e .   # 或 pip install -e .

# 安装无头浏览器
patchright install chromium
```

### 1b. 环境准备（Windows 本地登录/调试）
**用途**：抖音/B站/小红书/快手等平台登录扫码需有头浏览器，Windows 本地跑最稳。

```powershell
# 1. 复制项目到 Windows（从共享文件夹）
# PowerShell 管理员
cp -r \\10.10.10.30\shared\social-auto-upload E:\projects\
# 或：浏览器打开 http://10.10.10.30:8080/ 下载整个文件夹
cd E:\projects\social-auto-upload

# 2. 安装依赖（避免 C++ 编译工具报错）
# 原仓库 requirements.txt 是 UTF-16 带 null 字节，pip 直接读会乱码
# aiohttp==3.9.5 在 Python 3.13+ 无 wheel，需升级版本
# 使用修复版 requirements_win.txt（UTF-8，兼容版本）：

@"
aiofiles==24.1.0
aiohttp==3.11.15
aiohttp-cors==0.8.1
aiosignal==1.3.2
alembic==1.16.1
anyio==4.9.0
asgiref==3.8.1
async-lru==3.0.1
async-timeout==4.0.3
attrs==25.3.0
backports-datetime-fromisoformat==2.0.3
billiup==0.4.98
blinker==1.9.0
Brotli==1.1.0
certifi==2025.4.26
cf-clearance==0.31.0
cffi==1.17.1
charset-normalizer==3.4.2
click==8.2.1
colorama==0.4.6
dnspython==2.7.0
eventlet==0.40.0
exceptiongroup==1.3.0
Flask[async]==3.1.1
flask-cors==6.0.0
frozenlist==1.6.0.post1
greenlet==3.2.2
h11==0.16.0
h2==4.2.0
hpack==4.1.0
hyperframe==6.1.0
idna==3.10
isodate==0.7.2
itsdangerous==2.2.0
Jinja2==3.1.6
jsengine==1.0.7.post1
loguru==0.7.3
lxml==5.4.0
Mako==1.3.10
MarkupSafe==3.0.2
multidict==6.4.4
outcome==1.3.0.post0
pillow==11.2.1
pip-sys-ver==0.6.1
pyasn1==0.6.1
pycountry==24.6.1
pycparser==2.22
pycryptodome==3.23.0
pydantic==13.0.0
PySocks==1.7.1
PyYAML==6.0.2
qrcode==8.2
requests==2.32.3
rsa==4.9.1
schedule==1.2.2
sniffio==1.3.1
sortedcontainers==2.4.0
SQLAlchemy==2.0.41
stream-gears==0.2.2
streamlink==7.3.0
tomli==2.2.1
tomli-w==1.2.0
trio==0.30.0
trio-websocket==0.12.2
truststore==0.10.1
typing_extensions==4.13.2
urllib3==2.4.0
websocket-client==1.8.0
Werkzeug==3.1.3
win32-setctime==1.2.0
wrapt==1.16.0
xhs==0.2.13
yaml==1.20.0
yt-dlp==2025.5.22
"@ > requirements_win.txt

pip install -r requirements_win.txt
playwright install chromium
```

**关键点**：
- `aiohttp==3.11.15` 有 Python 3.13 wheel，避免 C++ 编译
- 若仍报错：`pip install --only-binary :all: -r requirements_win.txt` 强制只用 wheel
- 或安装 [Visual C++ Build Tools](https://visualstudio.microsoft.com/visual-cpp-build-tools/)（勾选 C++ build tools + Windows 10 SDK）

# 3. Windows 登录抖音（有头模式，稳定）
```powershell
python sau_cli.py douyin login --account her2home
```
- 终端显示 ASCII 二维码（Windows Terminal 支持 UTF-8）
- 或打开生成的 PNG：`cookies/douyin_her2home_login_qrcode_*.png`
- 浏览器自动打开确认页，扫码后 Cookie 自动保存

# 4. 验证并同步 Cookie 回 Linux
```powershell
python sau_cli.py douyin check --account her2home
```
登录成功后，把 `cookies/` 整个文件夹同步回共享文件夹（或直接在共享文件夹操作），Linux 定时任务即可复用 Cookie。

### 2. 配置文件
```bash
cp conf.example.py conf.py
# 编辑 conf.py：设置 BASE_DIR、代理、调试模式等
```

### 3. CLI 入口关键点（本次会话新增）
**必须在项目目录 `/home/kan/shared/social-auto-upload` 下运行**，`conf.py` 需存在。

**真实入口**：`python -m sau_cli` 或 `python sau_cli.py`（项目自带 CLI 模块）。

⚠️ **PyPI `sau` 包（`pip install sau`）是 AWS EC2 卷导出工具，完全不同项目**。安装了也不能直接用 `sau` 命令。

**Wrapper 修复**（加到 PATH 后可直接用 `sau`）：
```bash
cat > /home/kan/shared/social-auto-upload/sau_wrapper.sh << 'EOF'
#!/bin/bash
export PYTHONPATH=/home/kan/shared/social-auto-upload
exec python3 -m sau_cli "$@"
EOF
chmod +x /home/kan/shared/social-auto-upload/sau_wrapper.sh
ln -sf /home/kan/shared/social-auto-upload/sau_wrapper.sh ~/.local/bin/sau
```

### 4. 首次登录（扫码，仅需一次）
```bash
# 交互式登录所有平台
sau douyin login --account <account_name> --headless
sau bilibili login --account <account_name>
sau xiaohongshu login --account <account_name> --headless
sau kuaishou login --account <account_name> --headless
```
- Cookie 自动持久化到 `cookies/` 目录
- 后续运行自动复用，无需重复扫码

### 5. 视频发布命令模板
```bash
# 抖音（竖版封面 3:4）
sau douyin upload-video --account <name> \
  --file video.mp4 --title "标题" --desc "简介" --tags "标签1,标签2" \
  --thumbnail-portrait cover.png \
  --schedule "2026-06-28 08:30"

# B站（横版封面 16:9，需分区 tid）
sau bilibili upload-video --account <name> \
  --file video.mp4 --title "标题" --desc "简介" --tags "标签1,标签2" \
  --tid 249 --thumbnail-landscape cover.png \
  --schedule "2026-06-28 08:30"

# 小红书
sau xiaohongshu upload-video --account <name> \
  --file video.mp4 --title "标题" --desc "简介" --tags "标签1,标签2" \
  --thumbnail cover.png --schedule "2026-06-28 08:30"

# 快手
sau kuaishou upload-video --account <name> \
  --file video.mp4 --title "标题" --desc "简介" --tags "标签1,标签2" \
  --thumbnail cover.png --schedule "2026-06-28 08:30"
```

## 抖音二维码登录稳定性增强（本次会话新增）

### 问题
抖音二维码有效期极短（约 2-3 分钟），且每次刷新生成新文件名，导致远程手机扫码时链接指向旧文件。

### 解决方案：固定链接指向最新二维码
在 `_save_douyin_qrcode()` 中新增软链创建逻辑：
```python
# 创建/更新固定链接指向最新二维码
latest_link = qrcode_path.parent / f"douyin_{Path(account_file).stem}_latest_qrcode.png"
try:
    if latest_link.exists() or latest_link.is_symlink():
        latest_link.unlink()
    latest_link.symlink_to(qrcode_path.name)
except Exception:
    pass
```

**稳定访问链接**（无需刷新浏览器）：
- **局域网**: `http://10.10.10.30:8080/social-auto-upload/cookies/douyin_her2home_latest_qrcode.png`
- **Tailscale（推荐远程）**: `http://100.84.133.58:8080/social-auto-upload/cookies/douyin_her2home_latest_qrcode.png`

### 自动刷新频率
每 30 秒主动点击「刷新」按钮（poll_interval=3s, 10*3=30s），配合软链自动更新。

### 远程扫码最佳实践
1. **首选 Tailscale** — 已有节点 `100.84.133.58`，手机开 Tailscale 直接访问固定链接
2. 备选 ngrok — 需认证，临时隧道配置繁琐
3. 打开固定链接，**无需刷新**，对着屏幕用抖音扫一扫

### 自动化管线设计

### 文件约定（马小v 产出 → 共享文件夹）
```bash
/home/kan/shared/her2home/
├── video_20260628.mp4          # 视频文件
├── video_20260628.png          # 封面图（建议同时准备横版/竖版）
└── video_20260628.json         # 元数据
```

**注意**：马小v 实际产出在 `/home/kan/shared/her2home/signal_pop/weekly/`（周刊）或 `signal_pop/daily/`（每日），**自动化脚本只扫描主目录**。需先移动到主目录并配套 JSON + 封面。

**⚠️ 关键坑点（本次会话新增）**：
1. **封面命名必须与视频同名**：脚本按 `video_YYYYMMDD.mp4` 找 `video_YYYYMMDD.png/.jpg`。马小v 产出的封面常叫 `cover_YYYYMMDD.png`，**需手动重命名**，否则脚本报 "缺少封面" 跳过发布。
2. **视频源目录可能不在 `/her2home/`**：本次视频在 `/home/kan/shared/upload/signal_pop_daily_20260629.mp4`，**需先复制/重命名到 `/her2home/video_YYYYMMDD.mp4`**。
3. **Playwright Chromium 必须预装**：无头模式上传（小红书、快手、抖音）依赖 `playwright install chromium`，未装会报 `Executable doesn't exist at .../chrome` 导致发布失败。
4. **YouTube 支持已存在但未启用**：`uploader/youtube_uploader/main.py` 完整实现，CLI 有 `sau youtube upload-video`，但 `auto_publish.py` 的 `PLATFORMS` 列表未加 `"youtube"`。需发布时手动加入或修改脚本。
5. **Facebook/IG 不支持**：项目无上传器，Graph API 需审核，个人号基本不可用。

### 元数据 JSON 格式
```json
{
  "title": "隔天信号弹 6.28｜标题",
  "desc": "简介内容...",
  "tags": "隔天信号弹,AI,科技资讯",
  "schedule": "2026-06-28 08:30"
}
```

### 自动分发脚本核心逻辑
1. **扫描**目录下 `*.mp4`
2. **匹配**同名 `.png/.jpg` 封面 + `.json` 元数据
3. **去重**检查 `.publish_state.json` 记录
4. **顺序**调用 `sau` 上传（B站 → 小红书 → 快手 → 抖音，每平台间隔 5-10 秒，避免浏览器并发冲突）
5. **记录**成功/失败状态，失败下轮重试

**⚠️ 人工确认模式（本次会话新增）**：
用户要求**每次发布前必须人工确认** — 脚本跑完扫描、发现新视频后，**暂不自动上传**，等用户确认 "可以发布了" 再执行上传步骤。当前 `auto_publish.py` 为全自动，需改造或手动触发单平台上传命令。

### 平台特定参数（自动分发脚本内置）
| 平台 | `--tid` | 封面参数 | `--headless` | 备注 |
|------|---------|----------|--------------|------|
| B站 | 249 (科技/数码) | **无** (CLI 不支持) | 否 | 有头模式扫码更稳，注意频率限制（投稿过于频繁 code 21566） |
| 小红书 | 无 | **不加** (`--thumbnail` 有 Bug) | **是** | 封面上传卡死，暂不传 |
| 快手 | 无 | `--thumbnail` | **是** | 含封面、定时全通，Cookie 易失效需定期 check |
| 抖音 | 无 | `--thumbnail-portrait` | **是** | 竖版封面 3:4，需先登录，二维码固定链接方案见下文 |

### Cron 任务配置
| 任务 | 频率 | 用途 |
|------|------|------|
| 监控文件完整性 | 30 分钟 | 检查视频/封面是否完整、报警 |
| 自动分发 | 30 分钟 | 发现新视频 → 并行多平台发布 |

**实际调度时间（配合团队节奏）**：
- 虾小图产出新闻稿：08:00-08:30
- 马小v 生成视频：~10:00
- 自动分发检查：**10:30 和 16:30** 两次/天（足够覆盖，无需 30 分钟频率）
- 周刊：周六 09:00 发布

## 常见坑点与规避（本次会话新增）

| 问题 | 解决方案 |
|------|----------|
| `sau` 命令找不到模块 | 必须设置 `PYTHONPATH` 或用 `python -m sau_cli` |
| patchright chromium 下载 404 | 直连官方 CDN：`patchright install chromium`（别用镜像源） |
| 无头模式登录失败 | 抖音/快手/小红书加 `--headless`，B站建议有头模式扫码 |
| Cookie 过期 | `sau <platform> check --account <name>` 验证，失效重新 login |
| 定时发布时区 | 服务器时区必须为 Asia/Shanghai，`schedule` 使用本地时间 |
| 封面比例不符 | 抖音/快手/视频号：`--thumbnail-portrait` (3:4) + `--thumbnail-landscape` (4:3)；B站/小红书：`--thumbnail-landscape` (16:9) |
| **抖音二维码登录超时/失效** | **上游 Bug**：`_wait_for_douyin_login` 使用未定义变量 `original_url`、`saw_2fa`、`i` 导致崩溃；二维码有效期短（~4 分钟）且自动刷新不触发。**修复**：1) 补全变量初始化；2) 主动每 30 秒点击「刷新」按钮强制换码（见 `uploader/douyin_uploader/main.py` 第 197-210 行）；3) 通过 HTTP 文件服务器 (10.10.10.30:8080) 分享最新二维码 PNG 供手机扫码，比终端 ASCII 码可靠。 |
| **小红书封面上传卡死** | 上游 Bug：`Locator.wait_for: Timeout 30000ms exceeded` 等待 `div.d-modal.cover-modal`。**规避**：小红书暂不传封面（去掉 `--thumbnail`），仅上传视频+定时。 |
| **快手 Cookie 易失效** | 手动上传后 cookie 可能更新/失效。定期 `sau kuaishou check`，失效重新 login。 |
| **并行上传浏览器冲突** | 4 平台并行导致网络/浏览器超时。**改为顺序执行**（B站 → 小红书 → 快手 → 抖音），每平台间隔 5-10 秒。 |
| **远程手机扫不了二维码** | 服务器在局域网，手机不在同网段。**方案**：Tailscale (100.84.133.58) + 固定链接 `http://100.84.133.58:8080/social-auto-upload/cookies/<platform>_<account>_latest_qrcode.png`。 |
| **视频文件在子目录** | 马小v 产出在 `/home/kan/shared/her2home/signal_pop/weekly/`，**自动化脚本只扫主目录**。需移动到主目录并配套 JSON + 封面。 |
| **定时时间已过** | B站要求发布时间 ≥5 分钟且 ≤15 天。JSON 元数据中 `schedule` 需设为明天 08:30/09:00，不可用过去时间。 |
| **B站投稿频率限制** | 错误代码 21566 "投稿过于频繁"。Cron 间隔 10:30/16:30 避免此问题，测试时勿连续发布。 |

## AI Agent 集成
项目内置 Skills 目录，可直接被 OpenClaw/Codex/Claude Code 调用：
- `skills/douyin-upload/SKILL.md`
- `skills/kuaishou-upload/SKILL.md`
- `skills/xiaohongshu-upload/SKILL.md`
- `skills/bilibili-upload/SKILL.md`

Agent Bootstrap Prompt: `docs/agent-bootstrap.md`

## 维护命令
```bash
# 更新项目
cd /home/kan/shared/social-auto-upload && git pull && uv pip install -e .

# 更新浏览器
patchright install chromium

# 查看发布状态
cat /home/kan/shared/her2home/.publish_state.json
```

## 关联文件
- `references/social-auto-upload-cli.md` — CLI 完整参数参考
- `references/douyin-qrcode-login-fix.md` — 抖音二维码登录 Bug 修复记录
- `references/douyin-qrcode-fix-patches.md` — 抖音二维码登录 Bug 精确补丁（可直接 apply）
- `references/youtube-facebook-support.md` — YouTube/Facebook 支持现状与配置（**含 Cookie 格式问题修复**）
- `references/douyin-login-flow.md` — **抖音登录 & 上传完整流程（2026-06-30 会话新增：扫码、固定链接、远程扫码、上传命令、坑点速查）**
- `references/windows-deployment.md` — Windows 本地部署与登录指南
- `templates/video_metadata.json.example` — 元数据模板
- `scripts/auto_publish.py` — 自动分发主脚本
- `scripts/login_all_platforms.sh` — 一键登录脚本