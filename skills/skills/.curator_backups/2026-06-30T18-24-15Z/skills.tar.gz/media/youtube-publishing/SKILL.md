---
name: youtube-publishing
skill: youtube-publishing
description: YouTube video publishing — descriptions, watermarks, SEO, upload best practices.
platforms: [linux]
---

# YouTube Publishing

Write SEO-optimized YouTube descriptions and prepare assets (watermark, thumbnail) for product promo videos.

## Trigger

- User says "帮我写一份上传视频到youtube的说明" / "write YouTube description"
- You need to publish a product promo video to YouTube
- User asks about YouTube video settings (watermark, description, tags)

## Description Format

Structure the description in this order for maximum SEO:

### 1. Title Line (First Line = Keywords)

```
ProductName — Tagline | Feature 1 / Feature 2 / Feature 3
```

Example:
```
QuickTranslate — 开源划词翻译 Chrome 插件 | 划词即译 / 截图OCR / 悬浮翻译
```

### 2. Overview (1-2 sentences)

Brief paragraph describing what the product/video is about. Front-load keywords.

### 3. Timestamped Highlights

```
✨ 功能亮点
00:00 - Feature 1 description
00:05 - Feature 2 description
00:10 - Feature 3 description
00:15 - More features
00:20 - CTA / Installation
```

Calculate timestamps from scene durations: `total_frames / fps`.

### 4. Links Section

```
🔗 链接
- Chrome Web Store → https://chromewebstore.google.com/...
- GitHub → https://github.com/...
- Website → https://...
```

Use `→` arrows, not bare URLs. Keep links concise.

### 5. Benefits / Features Section

Short bullet points with emoji checkmarks:

```
📌 Why choose ProductName?
- ✅ Benefit one
- ✅ Benefit two
- ✅ Benefit three
```

### 6. Call to Action + Hashtags

```
If helpful, [specific CTA].

#ProductName #Category #Keywords...
```

## Rules

### CRITICAL: No `<>` in Description

YouTube parses `<>` as HTML tags and WILL break the description. Never use `<` or `>` in the text.

| ❌ Wrong | ✅ Correct |
|----------|-----------|
| `<500ms` | `500ms 内` or `500ms以下` |
| `response < 1s` | `响应速度 1秒以内` |
| `>1000 users` | `1000+ 用户` |

### Watermark Specs

- Size: **150×150** pixels (YouTube enforces this)
- Placement: **bottom-right** corner
- Format: PNG with transparency (RGBA)
- Style: tech/clean, readable at small size
- The watermark is set via YouTube Studio → Customization → Branding

### Description Limitations

- No HTML or rich formatting (plain text only)
- Links ARE clickable (auto-detected by YouTube)
- Hashtags are indexed by YouTube search
- First ~150 characters are visible in search results — put key info here
- Timestamps work with `00:00 - description` format

## Pitfalls

- **`<>` characters**: Most common mistake. YouTube interprets these as HTML tags. Always replace with 内/以下/以上/等 natural Chinese text.
- **Timestamp mismatch**: If video duration is shorter than timestamps in description, YouTube shows an error. Always verify against actual video length.
- **Watermark too large**: 150×150 is YouTube's exact requirement. Larger images get cropped or rejected. Resize before uploading.
- **Watermark placement**: Must be bottom-right. Other positions may be rejected.
- **No table syntax**: YouTube descriptions don't support markdown tables. Use bullet lists or `Key: Value` format instead.
