# Cron Environment & Delivery Gotchas (Signal Pop)

## feedparser Missing in Cron Context

**Symptom**: `ModuleNotFoundError: No module named 'feedparser'` in cron logs, but `pip list` shows feedparser installed.

**Root Cause**: The hermes-agent venv Python (`/home/kan/.hermes/hermes-agent/venv/bin/python3`) has feedparser, but system Python (`/usr/bin/python3` = Python 3.12) does not. When cron runs scripts via subprocess, it may resolve `python3` differently than in an interactive shell.

**Fix**: Ensure feedparser is installed in the venv AND the script uses the venv Python:
```bash
/home/kan/.hermes/hermes-agent/venv/bin/pip install feedparser python-dateutil
```

**Verification**:
```bash
/home/kan/.hermes/hermes-agent/venv/bin/python3 -c "import feedparser; print('OK')"
```

## Telegram Bot 401 Unauthorized

**Symptom**: Cron job reports `401 Unauthorized` when sending MP3 via Telegram Bot API.

**Root Causes** (in order of likelihood):
1. Bot has not been started (/start) by the target user
2. Bot is not a member of the target group/channel
3. `CHAT_ID` in config does not match the actual target chat
4. Bot token is incorrect or revoked

**Diagnostic**:
```bash
BOT_TOKEN=$(grep TELEGRAM_BOT_TOKEN ~/.hermes/.env | cut -d= -f2)
curl -s "https://api.telegram.org/bot${BOT_TOKEN}/getMe"  # confirm token works
curl -s "https://api.telegram.org/bot${BOT_TOKEN}/sendMessage" \
  -d "chat_id=1921948418" -d "text=test"  # test send
```

**Signal Pop specific**:
- Home channel CHAT_ID: `1921948418` (direct message)
- Group/channel CHAT_ID: `-1003790311439`
- Bot: `xiaotu2026_bot`
- User must have sent `/start` to the bot first

## Output File Path Confusion

**Symptom**: "File not found" when looking for MP3 output.

**Root Cause**: After the 2026-05-13 directory split, canonical output moved:
- OLD (stale): `/home/kan/signal_pop/output/signal_pop_daily_latest.mp3` (root level, before split)
- NEW (canonical): `/home/kan/signal_pop/output/daily/signal_pop_daily_latest.mp3`
- NEW (canonical): `/home/kan/signal_pop/output/weekly/signal_pop_weekly_latest.mp3`

**⚠️ User expectation vs reality (2026-05-13)**: User expected files at `output/signal_pop_daily_latest.mp3` (root level) and had a mental model of files being on @her2小v's server, not on `/home/kan/signal_pop/`. Always clarify the actual output path explicitly when communicating with the user.

**Fix**: Always check `output/daily/` and `output/weekly/` subdirectories. Tell the user the exact path.

## MP3 Playback Fails on User's Side

**Symptom**: MP3 file exists and `file` command shows valid MP3 (`MPEG ADTS, layer III, v2`), but user's media player cannot open it.

**Root Cause**: MiMo TTS API produces MPEG-2 Layer III (mp3) which may not be compatible with all players (notably some mobile players and macOS QuickTime). The `file` command shows `MPEG ADTS, layer III, v2` — this is MPEG-2, not the more common MPEG-1 Layer III.

**Fix options**:
1. Use the WAV fallback: `/home/kan/signal_pop/output/signal_pop_daily_20260513_raw.wav` (lossless, universal compatibility)
2. Re-encode MP3 to standard MPEG-1 Layer III using moviepy:
   ```python
   from moviepy.editor import AudioFileClip
   audio = AudioFileClip("/path/to/input.mp3")
   audio.write_audiofile("/tmp/reencoded.mp3", codec='libmp3lame', bitrate='128k')
   ```
3. If ffmpeg/moviepy unavailable, the WAV file is always the safe choice

## filter_news.py Argv Parse Error in Cron

**Symptom**: Pipeline fails at Step 2 with `filter_news.py: error: argument --mode: expected one argument`.

**Root Cause**: `generate_audio_only.sh` invokes `filter_news.py --mode "$MODE"` using `=` syntax (`--mode=weekly`). `argparse` with `nargs=None` interprets `--mode=weekly` as the string `"=weekly"` as its value, which fails validation.

**Fix**: Always use space-separated syntax:
```bash
python3 "$SRC_DIR/filter_news.py" --mode weekly --top 12
```

**Also**: Always pass `--top` explicitly — `filter_news.py`'s default is 7, which is wrong for both daily (should be 10) and weekly (should be 12). Cron invocation example:
```
/bin/bash /home/kan/signal_pop/scripts/generate_audio_only.sh weekly
```
The shell script must then call `filter_news.py --mode weekly --top 12` (space-separated).

## Male Voice Triggering on Wrong Day — FIXED 2026-05-16

**Symptom**: Daily news (Mon/Wed/Fri) plays male voice instead of female.

**Root Cause**: Bug in `generate_audio_only.sh` line 37:
```bash
# WRONG — WEEKDAY fallback causes male voice whenever WEEKDAY==6
if [ "$MODE" == "weekly" ] || [ "$WEEKDAY" == "6" ]; then

# CORRECT — only weekly mode uses male voice
if [ "$MODE" == "weekly" ]; then
```

**Fix**: Removed the `|| [ "$WEEKDAY" == "6" ]` condition. Voice gender is now determined solely by `$MODE` from cron.

## BBC English News Not Translated to Chinese

**Symptom**: Items 10-12 in weekly edition appear in English — title and summary untranslated. User hears English narration.

**Root Cause**: BBC English RSS returns raw English. `MINIMAX_API_KEY` is not set in cron, so API-based translation silently fails. Pre-defined `ENGLISH_TRANSLATIONS` dict in `generate_script.py` is the primary mechanism.

**Fix**: Add new exact title matches to `ENGLISH_TRANSLATIONS` dict in `generate_script.py` — do not debug first. Dict keys must exactly match raw RSS title.

**Translations known as of 2026-05-23**:

| English title (exact) | Chinese |
|---|---|
| `Heat leaves Africa and Med in shade` | 非洲与地中海地区酷热难当，炙热天气或将刷新纪录 |
| `Can't cope without Catherine` | 社交媒体热议：凯特王妃的缺席带来的深刻影响 |
| `'Heat leaves Africa and Med in shade' and 'Can't cope without Catherine'` | 非洲与地中海地区酷热难当...；社交媒体热议凯特王妃缺席带来的深刻影响 |
| `Most people seeking green cards must now apply from outside the US` | 美国移民政策收紧：绿卡申请者须在境外提交申请 |
| `The space race to create gym equipment for future astronauts` | 太空健身房竞赛：科学家致力于为未来宇航员研发健身器材 |

## Network Connectivity (China Mainland Servers)

**Status (updated 2026-05-22)**: `api.telegram.org` is **NOT blocked** from this server. Both curl and Python requests successfully reach Telegram API. The bot token `8708781676:AAFc...` works for sendAudio and sendMessage.

**If api.telegram.org becomes unreachable**: Use a Telegram proxy/mirror, VPN, or Hermes gateway `deliver: origin` (let the gateway handle delivery).
