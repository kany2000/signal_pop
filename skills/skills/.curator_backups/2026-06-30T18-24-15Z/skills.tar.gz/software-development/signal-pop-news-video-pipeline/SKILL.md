---
name: signal-pop-news-video-pipeline
description: End‑to‑end pipeline for generating news videos for Signal Pop (隔天信号弹), covering both the legacy free‑asset approach AND the new Google Flow + Veo 3.1 zero‑cost AI video workflow.
author: Hermes Agent
version: 2.0.0
license: MIT
---

# Signal Pop News Video Pipeline

Two approaches exist for generating video content. **Prefer Google Flow (2026)** — it's free, higher quality, and simpler to operate.

---

## Approach A: Google Flow + Veo 3.1 (Recommended, 2026)

**Cost: $0.** No API keys, no infrastructure, no ffmpeg.

Google Flow (labs.google/fx/tools/flow) is a unified AI creative studio that bundles video generation, image generation, and editing — all free with a Google account.

### Tools inside Flow

| Tool | Purpose | Free tier |
|------|---------|-----------|
| **Veo 3.1** | Video generation with native audio (dialogue + lip-sync + SFX + music) | 20 credits/clip (Fast) |
| **Nano Banana** | Image generation, character consistency, precise editing | Included in Flow |
| **Gemini Omni** | Multimodal input, conversational editing, script generation | Included in Flow |

### Free Credits
- 100 starter + 50 daily credits
- Veo 3.1 Fast = 20 credits → **2–3 clips/day free**
- Veo 3.1 Lite = 10 credits → **5 clips/day free**
- 1080p upscale: free; 4K upscale: 50 credits
- **No watermark** on free tier

### Clip limits
- Single generation: 4–8 seconds
- Extend via chaining (7s hops × up to 20) → ~148 seconds (~2.5 min)
- Quality degrades after 3–5 hops; plan accordingly

### Workflow for Signal Pop

1. **Plan + script via Gemini Omni** — Gemini Omni is the multimodal hub inside Flow. Feed it reference images, video clips, or text prompts. Use it to plan visual direction and generate narration script.
2. **Create character reference via Nano Banana** — Generate subject‑consistent images (presenter/avatar/scene). Output serves as **reference image** for Veo.
3. **Seed Veo 3.1 with reference images** — Upload Nano Banana output as the starting image for Veo 3.1. This gives character consistency across clips. Prompt describes motion/dialogue from the script segment.
4. **Extend/chain** clips for longer segments (7s hops, ≤20 hops)
5. **Dialogue lip-sync** — Veo 3.1 generates native audio from text prompt. Script text in the prompt → synchronized speech.
6. **Download** 720p/1080p output

### Limitations
- Single clip ≤ 8s (need chaining for longer)
- Custom audio upload not supported (use Flow's native audio)
- Requires Google account; no programmatic API (web UI only)
- No direct API for automated pipeline — human-in-loop for now

### Access
- URL: https://labs.google/fx/tools/flow
- Sign in with any Google account (free)
- Region-locked? Check FAQ at labs.google/fx/tools/flow/faq

---

## Approach B: Legacy Free-Asset Pipeline (Deprecated)

The original Pexels + MoviePy pipeline has been **superseded** by Approach A. Kept here for reference.

> The user switched to audio-only (MP3 + text script) as of 2026-05-13. See **`signal-pop-audio-only-pipeline`** for the current working configuration.

### Prerequisites
- Python 3.11+ with `pip`.
- Internet access for RSS feeds and Pexels API (optional).
- **Optional**: `ffmpeg`/`ffprobe` for real video assembly. If unavailable, the pipeline falls back to a placeholder silent audio and an empty MP4.

### Project Structure
```
signal_pop_project/
├─ src/
│  ├─ fetch_news.py          # RSS fetch & 48h filter (fixed feedparser attribute)
│  ├─ filter_news.py         # Keyword scoring filter
│  ├─ generate_script.py     # Offline script generator (no LLM API required)
│  ├─ match_assets.py        # Pexels search, downloads clips/images
│  ├─ tts.py                 # Generates silent placeholder audio via pydub
│  ├─ assemble_video.py      # Creates placeholder MP4 (fallback when ffmpeg missing)
│  └─ upload.py              # Stub upload metadata
├─ assets/
│  ├─ clips/   (downloaded video clips)
│  ├─ images/  (downloaded images)
│  └─ audio/   (combined.wav created by tts.py)
├─ data/
│  ├─ raw_feed.json
│  ├─ filtered_news.json
│  ├─ script.txt
│  └─ final.mp4
├─ scripts/run_all.sh        # Orchestrates the whole pipeline
├─ docs/signal_pop_architecture.html  # Architecture diagram (generated)
└─ requirements.txt
```

### Common Pitfalls (Legacy)
- **Missing `published_parsed` attribute** – fixed by patching `fetch_news.py`.
- **OpenAI/Large‑model API key not set** – replaced LLM call with offline generator.
- **`ffmpeg` not installed** – `assemble_video.py` now falls back to creating an empty MP4 so the pipeline never aborts.
- **Pexels API quota** – limit to one result per headline; failures are logged but do not stop the pipeline.

# References
- Google Flow landing: https://labs.google/fx/tools/flow
- Veo 3.1 model: https://deepmind.google/models/veo/
- Nano Banana (Gemini Image): https://deepmind.google/models/gemini-image/
- Google Flow FAQ: https://labs.google/fx/tools/flow/faq
- **HyperFrames evaluation** — `references/hyperframes-evaluation-2026.md` (this skill)
- **多平台自动分发** — `multi-platform-video-publishing` skill (devops)
- **social-auto-upload 项目** — `/home/kan/shared/social-auto-upload/`

---

## 多平台自动分发（完整管线的最后一步）

视频生成（Approach A 或 B）完成后，产出文件：
```
/home/kan/signal_pop/daily/output/signal_pop_daily_YYYYMMDD.mp4
/home/kan/signal_pop/daily/output/cover_YYYYMMDD.png
```

### 1. 准备分发文件（按 social-auto-upload 约定）
```bash
DATE=20260630
cp /home/kan/signal_pop/daily/output/signal_pop_daily_${DATE}.mp4 \
   /home/kan/shared/her2home/video_${DATE}.mp4
cp /home/kan/signal_pop/daily/output/cover_${DATE}.png \
   /home/kan/shared/her2home/video_${DATE}.png
```

创建元数据 JSON：
```json
{
  "title": "隔天信号弹 ${DATE}",
  "desc": "这里是隔天信号弹，今日关注：...",
  "tags": "新闻,时事,AI科技,隔天信号弹",
  "schedule": "2026-07-01 08:30"
}
```
保存为 `/home/kan/shared/her2home/video_${DATE}.json`

### 2. 登录各平台（首次/失效时）
```bash
cd /home/kan/shared/social-auto-upload

# YouTube（系统 Chrome，已登录 her2home）
sau youtube login --account her2home

# 抖音（有头模式扫码，Windows 本地跑）
sau douyin login --account her2home

# B站（扫码）
sau bilibili login --account her2home

# 小红书（扫码）
sau xiaohongshu login --account her2home

# 快手（扫码）
sau kuaishou login --account her2home
```

### 3. 视频上传（立即/定时发布）
```bash
DATE=20260630
VIDEO=/home/kan/shared/her2home/video_${DATE}.mp4
COVER=/home/kan/shared/her2home/video_${DATE}.png
TITLE="隔天信号弹 ${DATE}"
DESC="这里是隔天信号弹，今日关注：..."
TAGS="新闻,时事,AI科技,隔天信号弹"

# YouTube（立即公开）
sau youtube upload --account her2home \
  --file "$VIDEO" --title "$TITLE" --description "$DESC" --tags "$TAGS"

# 抖音（竖版封面 3:4，定时次日 08:30）
sau douyin upload-video --account her2home \
  --file "$VIDEO" --title "$TITLE" --desc "$DESC" --tags "$TAGS" \
  --thumbnail-portrait "$COVER" \
  --schedule "2026-07-01 08:30"

# B站（横版封面 16:9，分区 tid=199 时政/21 数码）
sau bilibili upload-video --account her2home \
  --file "$VIDEO" --title "$TITLE" --desc "$DESC" --tid 199 --tags "$TAGS" \
  --thumbnail-landscape "$COVER" \
  --schedule "2026-07-01 08:30"

# 小红书（视频，定时）
sau xiaohongshu upload-video --account her2home \
  --file "$VIDEO" --title "$TITLE" --desc "$DESC" --tags "$TAGS" \
  --thumbnail "$COVER" \
  --schedule "2026-07-01 08:30"

# 快手（视频，定时）
sau kuaishou upload-video --account her2home \
  --file "$VIDEO" --title "$TITLE" --desc "$DESC" --tags "$TAGS" \
  --thumbnail "$COVER" \
  --schedule "2026-07-01 08:30"
```

### 4. 自动分发入口（cron 触发后 agent 主动跑）
`auto_publish.py`：扫描 `/home/kan/shared/her2home/` 目标文件夹，按命名规则 `video_YYYYMMDD.mp4` + `.png` + `.json` 上传并定时。

**cron 暂停中**，人工确认后触发：
```bash
cd /home/kan/shared/social-auto-upload && python auto_publish.py
```

### ⚠️ 分发层已知坑
| 平台 | 问题 | 规避 |
|------|------|------|
| YouTube | 未审核 API 项目上传强制私有 | 用浏览器自动化（已实现），可直接公开 |
| 抖音 | Cookie 校验无头会误判失效 | 代码强制 `headless=False` 校验；Linux 需虚拟显示 |
| 抖音 | 二维码 2 分钟失效 | 登录脚本每 30 秒自动刷新二维码 |
| 抖音 | 触发短信/二次验证 | 浏览器弹窗需人工输验证码，脚本等待 |
| B站 | 频率限制（同 IP/账号） | 间隔 ≥10min，账号轮换 |
| 小红书/快手 | 相对稳定 | 正常跑即可 |
| 视频号/百家号 | 暂未接入 | 待需求时接入 |

### 关键路径汇总
```
cron(TTS+SRT) → HyperFrames渲染 → 生成MP4+封面
    → cp到/her2home/重命名video_YYYYMMDD.*
    → 创建video_YYYYMMDD.json元数据
    → sau上传各平台（立即/定时）
    → 发群（Telegram HTTP链接+封面）
```
