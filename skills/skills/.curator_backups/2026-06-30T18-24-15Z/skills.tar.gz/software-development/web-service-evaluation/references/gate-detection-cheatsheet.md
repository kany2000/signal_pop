# Gate Detection Cheatsheet

## CAPTCHA Providers

| Provider | DOM Signature | Token Field | Solve Cost |
|----------|---------------|-------------|------------|
| **Cloudflare Turnstile** | `<div id="cf-turnstile">` or `data-sitekey` | `cf-turnstile-response` | $1-3/1k (2Capsolver, CapMonster) |
| **hCaptcha** | `<div class="h-captcha">` | `h-captcha-response` | $2-4/1k |
| **reCAPTCHA v2** | `<div class="g-recaptcha">` | `g-recaptcha-response` | $1-2/1k |
| **reCAPTCHA v3** | Invisible, `grecaptcha.execute()` | `g-recaptcha-response` | Harder (score-based) |

## Rewarded Ad Gates

| Provider | JS Global | Trigger | Signal |
|----------|-----------|---------|--------|
| **BuySellAds** | `window.bsa`, `bsaPro` | `showRewardedAd()` | `rewardedSlotReady` event |
| **Google AdMob** | `googletag`, `googletag.cmd` | `googletag.pubads().refresh()` | `slotReady` + `rewarded` |
| **Unity Ads** | `UnityAds` | `UnityAds.show()` | `onUnityAdsComplete` |

## Request Payload Indicators

```json
// Turnstile/hCaptcha proof
{"question": "...", "interactionProof": "0.xxx...", "model": "..."}

// Rewarded ad proof
{"prompt": "...", "adViewProof": "eyJhbGciOi...", "model": "..."}

// Session cookie required
Cookie: session_id=abc123; cf_clearance=xyz...
```

## Response Signatures

| Response | Meaning |
|----------|---------|
| `{"error":"Unauthorized"}` | No auth header/cookie |
| `{"error":"Unauthorized request"}` | Invalid/missing browser fingerprint |
| `{"error":"CAPTCHA required"}` | Must solve challenge first |
| `{"error":"Ad view required"}` | Must complete rewarded ad |
| `{"error":"Rate limited"}` | Too many requests |
| `{"error":"Model unavailable"}` | Backend queue full |

## Quick curl Tests

```bash
# 1. Baseline - no headers
curl -X POST "$URL/api/endpoint" -d '{}'

# 2. With JSON content-type
curl -X POST "$URL/api/endpoint" -H "Content-Type: application/json" -d '{"test":true}'

# 3. With browser-like headers
curl -X POST "$URL/api/endpoint" \
  -H "Content-Type: application/json" \
  -H "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64)..." \
  -H "Origin: $BASE" \
  -H "Referer: $BASE/tools/..." \
  -d '{}'

# 4. With session cookie (if you have one)
curl -X POST "$URL/api/endpoint" \
  -H "Cookie: session=...; cf_clearance=..." \
  -d '{}'
```

## Decision Matrix

| Signals | Verdict | Action |
|---------|---------|--------|
| All endpoints work with curl | **Programmatic** | Use directly |
| Chat works, image gen needs CAPTCHA | **Partial** | Chat API only |
| All need Turnstile + ad gate | **Browser-only** | Playwright + solver |
| 404 on claimed endpoints | **Fake/Deprecated** | Abandon |
| Generic errors, no model info | **Proxy/Reseller** | Find upstream |