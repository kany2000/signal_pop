---
name: tournament-motivation-analysis
description: Analyzing the impact of tournament qualification status on match outcomes, specifically identifying "rotation" (轮换) or "throwing" (放水) patterns in group stage finals.
---

# Tournament Motivation Analysis

Analyzing the impact of tournament qualification status (e.g., group stage finals) on match outcomes, specifically identifying "rotation" (轮换) or "throwing" (放水) patterns.

## Methodology
In tournament group stages, a team's motivation shifts once their qualification status is mathematically decided. Pure strength-based predictions (Elo, Form) often fail in the final group match if the incentives are misaligned.

### The Motivation Matrix (Group Stage Finals)
Use this matrix when a strong team has already secured a high seed or qualification:

| Scenario (Strong Team $\rightarrow$ Opponent) | Expected Behavior | Probability Trend |
| :--- | :--- | :--- |
| **Locked #1 $\rightarrow$ Opponent Out (0 pts)** | Low intensity, minimal risk, low urgency | High Draw Probability |
| **Locked #1 $\rightarrow$ Opponent Fighting for Life (1-3 pts)** | High volatility; Opponent high intensity vs Strong team's low intensity | Win or Loss (Low Draw) |
| **Fighting for #1 $\rightarrow$ Fighting for #1** | Maximum intensity from both sides | Normal Strength-based Analysis |
| **Locked #1 $\rightarrow$ Opponent Stable (4+ pts)** | Controlled match, minimal risk | Strong Team Favor (Low Risk) |

## Workflow
1. **Compute Standings**: Calculate current points, GF/GA after the penultimate matchday.
2. **Determine Qualification Status**:
   - Identify if the favorite is mathematically qualified regardless of the result.
   - Identify if the favorite is fighting for the top seed.
3. **Analyze Opponent's Incentive**:
   - Does the opponent *need* a specific result (Win/Draw) to advance?
   - Is the opponent already eliminated?
4. **Adjust Prediction**: Apply the Motivation Matrix to override or modify the baseline prediction.

## Pitfalls
- **The "Reserve Strength" Fallacy**: Do not assume a top team will lose simply because they rotate. The reserves of a world-class team are often superior to the starters of a bottom-tier team.
- **Bracket Manipulation**: Be aware of "strategic throwing" where teams intentionally seek a specific seed to avoid a powerhouse in the knockout stage.
- **Ignoring Home Advantage**: In hosted tournaments, the host's motivation to win every game is usually higher even if they are already qualified.

## References
- `references/worldcup-motivation-baseline.md`: Historical baseline from 2014-2022 World Cups.
