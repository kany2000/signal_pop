# World Cup Motivation Baseline (2014-2022)

Analysis of teams entering the final group match with 6 points (2 wins).

## General Statistics
- **Total Sample**: 17 matches.
- **Outcomes**: 
  - Win: 41%
  - Draw: 18%
  - Loss: 41%
- **Observation**: Results are evenly split. "Throwing" is a real risk, but not a guarantee.

## Scenario-Specific Performance

### 1. Locked #1 $\rightarrow$ Opponent Out (0 pts)
- **Sample**: 1 match
- **Result**: 100% Draw
- **Conclusion**: Highest probability of "mutual resting."

### 2. Locked #1 $\rightarrow$ Opponent Fighting for Life (1-3 pts)
- **Sample**: 6 matches
- **Result**: 50% Win / 50% Loss (0% Draw)
- **Conclusion**: High volatility. The "desperation" of the underdog often overrides the "rotation" of the favorite.

### 3. Locked #1 $\rightarrow$ Opponent Stable (4+ pts)
- **Sample**: 2 matches
- **Result**: 50% Win / 50% Draw (0% Loss)
- **Conclusion**: Strong team tends to maintain dominance or settle for a draw.

### 4. Locked #1 $\rightarrow$ Opponent Fighting for Seed (3 pts)
- **Sample**: 2 matches
- **Result**: 0% Win / 50% Draw / 50% Loss
- **Conclusion**: High risk of upset when the opponent has a realistic path to a higher seed.

### 5. Fighting for #1 $\rightarrow$ Fighting for #1
- **Sample**: 6 matches
- **Result**: 50% Win / 50% Loss (0% Draw)
- **Conclusion**: Normal competitive match.
